# M18：Engine 0.2.1 多灯光与渲染性能迭代

## 硬件合同修订 — 2026-10-06

用户明确批准调整合同并继续 G09。按 [ADR 0117](../../../Engine/docs/for-ai/adr/0117-native-021-hardware-scope.md)，必需验收采用一条完整原生路径：Windows 独显 Chrome＋Edge，或 macOS Apple Silicon/AMD Metal Chrome。旧 Intel Gen9 集显为非阻塞 extended 兼容；保留原失败，不宣称已修复。原质量、场景、独显性能/内存预算和 3×300 CPU/GPU、120 帧预热、实测 120 秒冷却均不变。新主机重新建立同机基线；G09/G05 未因范围修订完成，G07 仍依赖其完整证据。以下早期双设备检查点保留为历史。


状态：`active`（G01–G04、G06 complete；G05 active / 未通过；G07、G08 draft；G09 active / 阶段六正确性回归与对照诊断）。规划日期：2026-09-25；状态更新：2026-10-06。新增 FrameGraph 生产集成与前后收益验收为 0.2.1 必做目标，已实现真实依赖、裁剪、临时纹理复用与计划缓存，尚未开始正式性能采样或发布。

## 版本目标

让 Engine 能完整渲染上百盏动态局部灯，并提供可观察、可测量的 deferred rendering（延迟渲染）路径。以当前 Forward 路径为小场景默认，以按需启用的 Deferred 路径承接多灯场景；复用已有帧计划、Shader Language、GPU 实例及诊断设施。

规划以 Engine `release/0.2.1` 的 `365552908414ffa193c63a62aaf682f4ddb23b94` 为源码观察点。该分支的包版本已经是 0.2.1；GPU 实例、LOD、异步读回已有开发验证，本计划接续这些成果，不重复立项，也不等于认可其全部设备性能。

## 优先级与范围

| 优先级 | 迭代项 | 本版交付 |
| --- | --- | --- |
| P0 | Deferred 主路径 | PBR 不透明/alpha-mask 的 G-buffer、HDR 光照合成、深度重建、storage light buffer；完整计算 128 盏动态点光源 |
| P0 | 多灯性能 | Tiled Deferred：按屏幕分块生成灯光索引，保留全灯遍历参考路径；正确剔除、无静默丢灯、可解释的溢出处理 |
| P0 | 现有场景兼容 | 透明与特殊材质混合 Forward、现有方向光阴影、IBL/AO/雾、TAA/运动矢量、实例/变形、多视图和资源恢复 |
| P0 | 可见效果与验收 | `deferred-lighting` 示例、G-buffer/分块热力图、逐灯开关、同一场景对照；一条完整原生资格路径与独立 Engine 发布门禁 |
| P1 必做 | FrameGraph 集成与收益验收 | 将依赖裁剪、瞬态资源复用、计划缓存接入生产渲染；量化前后 CPU/GPU、资源峰值和工作量，详见 G09 |
| P1 | 帧资源与 CPU 开销 | 按需分配 G-buffer，复用兼容深度/法线，消除重复上传与稳定帧对象创建；量化 CPU、GPU、上传量和资源高水位 |
| P1 | 已有 GPU 实例性能资格 | 1k/10k 实例、单/四视图、LOD 与剔除的配对基准；保留不读回实例数据的正常帧路径 |
| 候选 P1 | 无文本动画按需加载字体 | 已知同步字体解析器成本值得拆分；先评估兼容入口与收益，另立实施 Goal，不阻塞多灯主线 |
| 后续 P2 | SpotLight、局部灯阴影 atlas、CSM、3D clustered、Hi-Z、动态分辨率 | 记录触发条件与验收方向，不一并塞入 0.2.1 |

**数量目标是待实现目标，不是已有测试结论：**128 灯为最低功能验收，256 灯为扩展验收，512/1024 灯为压力诊断。128/256 的指定完整覆盖场景中，合格灯光全部进入光照计算，不得把 authored 数量当作实际处理数量。大量灯光默认无局部阴影；阴影成本独立核算。

## 执行顺序

| Goal | 直接依赖 | 独立产出 |
| --- | --- | --- |
| [G01](./goals/g01-contracts-baseline.md) | 无 | 设备/场景基线、架构决策、材质矩阵和预算冻结 |
| [G02](./goals/g02-deferred-core.md) | G01 | 正确的全灯 Deferred 参考实现及 128/256 灯输出 |
| [G03](./goals/g03-tiled-lighting.md) | G02 | 分块剔除、完整灯光列表、溢出回退与配对证据 |
| [G04](./goals/g04-rendering-compatibility.md) | G03 | 材质/后处理/阴影/多视图/恢复兼容闭环 |
| [G05](./goals/g05-performance-qualification.md) | G04 | 帧资源优化与既有 GPU 实例、多灯性能资格 |
| [G06](./goals/g06-example-diagnostics.md) | G04 | 交互示例、效果对照、调试视图与使用指南 |
| [G07](./goals/g07-release-candidate.md) | G05、G06、G09 | 同一候选的独立 Engine 验收与发布资料 |
| [G08](./goals/g08-cross-engine-device-baselines.md) | G06 | 独立的跨引擎/设备分档研究，不作为新增发布门禁 |
| [G09](./goals/g09-framegraph-optimization.md) | G04、G06 | FrameGraph 生产集成、真实资源映射与同画质前后对照 |

采用串行执行，避免各 Goal 同时修改帧计划、光照 ABI 与 Shader 生成器。机器状态、依赖及写入范围以 [milestone.json](./milestone.json) 为准。当前 G01–G04、G06 为 complete，G05 为 active 且未通过，G07/G08 为 draft，G09 为 active。G09 实施后需在最终优化候选重跑 G05，G07 同时要求 G05/G06/G09 完成。G04 的[兼容性审计](../../../Engine/review/engine-0.2.1/g04-compatibility-audit.md)及[G05 交接](../../../Engine/review/engine-0.2.1/g05-handoff.md)已完成。合同与预算已冻结；G02 的 128/256 灯完整覆盖、资源复用与四视图正确性验收见 [完成审计](../../../Engine/review/engine-0.2.1/g02-completion-audit.md)。G03 的[完成审计](../../../Engine/review/engine-0.2.1/g03-completion-audit.md)与[G04 交接](../../../Engine/review/engine-0.2.1/g04-handoff.md)已准备；高重叠绝对性能目标、完整设备资格与发布验收仍由 G05/G07 完成。

## 阅读顺序

1. [当前能力与后续机会](./assessment.md)：源码、历史验收和官方示例的证据边界。
2. [架构与兼容合同](./contracts.md)：数据所有权、渲染顺序、材质与失败行为。
3. [验收与集成](./integration.md)：场景矩阵、性能预算、设备要求和发布边界。
4. [机器计划](./milestone.json) 与当前 Goal 文档。

## 独立发布边界

仅覆盖 Engine 仓内库、示例与资料；不依赖 UI、Editor、AIStudio、Games 的构建或版本变化。Rive 保持独立分支工作，不纳入此版本。WebGL2 fallback、Native/Rust 路线分别保持自己的里程碑，本计划不为它们承诺 Deferred 支持。

0.2.1 不删除或改变 stable API 语义；新增渲染能力先走显式 experimental profile，普通场景不额外加载全部 Deferred shader。若必须破坏公开合同，登记下一 minor 的迁移计划，不借 patch 版本强行升级。完成 G07 交付发布候选，不自动执行 publish、tag 或 push。

## G05 最新性能验收（2026-09-28）

[GPU 与全量性能审计](../../../Engine/review/engine-0.2.1/g05-gpu-performance-audit.md)为 **failed-and-incomplete**。当前代码的 Intel 高重叠完整单次采样超出 24 ms GPU 预算；Intel GTAO 长负载发生主机限速，随后三套全量入口被主机预检拦截。所有失败/未完成人口保留，不以单次样本或历史轮次提升资格。G05 保持 active，G06/G07 不激活，预算与发布边界不变。

## Evening resumption — 2026-09-28

See [current-source resumption audit](../../../Engine/review/engine-0.2.1/g05-resume-audit.md). The cooldown implementation now waits for the actual 120-second minimum; 190 policy tests pass. Current-source native pending/AO resources and package consumers pass on the documented scope. New full matrices fail host preflight, so G05 remains active and unqualified; G06/G07 remain draft. Previous attempts are preserved without splicing.

## 完整人口复测 — 2026-09-29

[最新完整性能审计](../../../Engine/review/engine-0.2.1/g05-full-performance-2026-09-29.md)已补齐 Forward、F、E/G 和高重叠/GTAO 三轮人口。原始证据完整性及主机前后检查通过，性能资格仍因预算与稳定性失败。G05 保持 active，G06/G07 保持 draft；未修改合同、预算或发布范围。较早的主机预检失败保留为历史，不代表这次完整复测的失败原因。

## 用户调整优先级 — 2026-09-29

先执行 G06 多灯示例；其直接依赖改为已完成的 G04。G05 的失败和预算仍保留，G07 显式依赖 G05 与 G06。新增独立的 [G08：跨引擎与设备分档评审](goals/g08-cross-engine-device-baselines.md)，当前 draft，不启动横向采样、不自动放宽预算。上文较早的串行状态是历史检查点，以机器计划为准。

## G06 验收 — 2026-09-29

多光源示例与最小实验入口已完成，[验收报告](../../../Engine/review/engine-0.2.1/g06-example-audit.md)包含构建、25 项浏览器交互、资源释放及打包结果。G05 active/unqualified；G07 draft；G08 draft。

## FrameGraph 规划加入本版 — 2026-10-01

[G09 完整计划](goals/g09-framegraph-optimization.md)包含六阶段改造、资源与副作用合同、A0/B4 最终对照及分阶段归因、两类 GPU 的统计矩阵和完成条件。依赖与裁剪子阶段已实现，结构计数、像素及兼容性结果见 [审计](../../../Engine/review/engine-0.2.1/g09/dependency-culling-audit.md)；临时纹理复用见 [资源审计](../../../Engine/review/engine-0.2.1/g09/resource-reuse-audit.md)，计划缓存及安全附件操作见 [阶段四审计](../../../Engine/review/engine-0.2.1/g09/plan-cache-audit.md)。阶段四专项双 GPU 对照通过，完整兼容矩阵仍有集显像素失败；持续稳定性及正式性能收益验收仍待后续阶段完成。G07 新增 G09 依赖，G05 的未达标记录与预算继续保留。

## G09 阶段六检查点 — 2026-10-02

用户已启动对照验收与回归接线。确定性策略检查接入 Engine fast gate；原生完整兼容性与示例检查接入 local/global release 链，复用已有构建，不进入 SwiftShader CI 的硬件资格范围。新增 312 次生命周期切换、设备重建及完整输出覆盖检查。

验收尚未通过：Intel 集显在候选 B4 出现空画面或仅 1 像素输出；固定旧生产版本 A0 的后续诊断也复现全黑，记录的输出尺寸和 viewport/scissor 正常。未认定浏览器或引擎根因，未启动正式性能采样。详见 [阶段六审计](../../../Engine/review/engine-0.2.1/g09/comparison-regression-audit.md)。G09/G05 保持 active，G07 保持 draft，预算不变。
