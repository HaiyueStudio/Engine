# 渲染与数据合同（G01 已冻结）

## 硬件合同修订 — 2026-10-06

用户明确批准调整合同并继续 G09。按 [ADR 0117](../../../Engine/docs/for-ai/adr/0117-native-021-hardware-scope.md)，必需验收采用一条完整原生路径：Windows 独显 Chrome＋Edge，或 macOS Apple Silicon/AMD Metal Chrome。旧 Intel Gen9 集显为非阻塞 extended 兼容；保留原失败，不宣称已修复。原质量、场景、独显性能/内存预算和 3×300 CPU/GPU、120 帧预热、实测 120 秒冷却均不变。新主机重新建立同机基线；G09/G05 未因范围修订完成，G07 仍依赖其完整证据。以下早期双设备检查点保留为历史。


G01 已于 2026-09-25 冻结。权威细节由 Engine 的 [ADR 0109](../../../Engine/docs/for-ai/adr/0109-deferred-lighting-021-contract.md) 和[机器配置](../../../Engine/config/lighting-performance-021.json)持有。以下保留规划约束索引；原文中交由 G01 决定的字段、顺序和矩阵现已由上述 ADR 明确，不是剩余待决项，也不宣称 API 已存在。

冻结补充：源 header 16 B、记录 64 B、view header 32 B；3×rgba16float + depth32float、sampleCount=1；2D Tiled 首版不使用 opaque min/max 深度剔除；每 tile 128 索引，溢出本帧遍历完整 view list。现有 Light/RenderView 没有 per-light layer-mask API，layer 用例验证既有视图/渲染层 owner 隔离，不新增该公开能力。材质扩展与透明 PBR 使用全灯 Forward 参考，特殊材质受限回退必须明确显示。详细 pass 图和字节偏移以 ADR 为准。

## 路径与顺序

1. 保留当前 Forward 默认行为。新增显式 experimental Deferred profile；本版不默认按灯数自动切换，以免相机移动造成质量或帧时间跳变。
2. 典型顺序：源数据更新/现有阴影 → opaque G-buffer → tile light culling → deferred HDR resolve → Forward 特殊不透明材质/透明 → 后处理 → 单次显示输出。AO、运动和特殊不透明物体的具体位置由资源依赖与覆盖语义决定，G01 必须冻结实际图，不能硬套该简图。
3. G-buffer 最少表达 PBR base color、normal、metallic、roughness、emissive、occlusion 与深度，世界坐标由深度重建。具体打包、法线空间、色彩空间、精度和 material flags 由 G01 配对验证后冻结。
4. 首版使用 sampleCount=1。现有 MSAA 场景继续走 Forward；显式请求不支持的 Deferred+MSAA 组合应有明确诊断和 documented fallback，不静默丢弃抗锯齿。Deferred 与 TAA 组合需要实际验收。
5. 普通 profile 不分配 G-buffer/tile list，不加载无关 Deferred shader family。生成器、反射、绑定布局和 WGSL 必须同源生成；不得手改 generated 文件。

## 灯光数据与正确性

- World/frame 拥有未截断的灯光源；camera/viewport/layer 拥有可见灯列表与 tile list。不得复用旧 8 槽数组作为 Deferred 的输入。
- 点光源使用 storage buffer，容量与 device limits、分配预算绑定；方向光与环境项独立表达，不消耗任意固定的局部灯名额。保留稳定灯 ID。
- 统计各视图的 `authored / invalid-or-disabled / outside-view-or-layer / eligible / submitted / capacity-overflow`，给出守恒关系；tile references 是可重复引用总量，不能冒充唯一灯数。GPU 求值与 reference 诊断按自己的维度记录。
- 指定 128/256 灯完整覆盖场景要求 `eligible == submitted`、容量溢出为 0。视锥/半径剔除无影响灯是正常结果，不算丢灯；用独立几何 oracle 验证无 false negative。
- tile 局部数组或总索引容量溢出必须保证画面正确：可以对溢出 tile 遍历全量已接收灯，或使用经过验证的等价回退。不得仅 clamp 数量。超出整帧 source buffer/device 支持范围时明确报能力限制，不标记 full coverage。
- 不能把读取 GPU 溢出标志后的下一帧修复当作本帧正确性；当前帧 shader 必须具备安全回退。动态更新、删除、相机切换不能沿用旧列表。
- Tiled 首版不包含 Z slice；若使用深度 min/max 做更紧剔除，必须处理背景、空 tile、近裁面、相机位于光球内、正交相机、reverse-Z 配置及 TAA jitter。

## 材质兼容表

| 材质/能力 | 0.2.1 最低合同 |
| --- | --- |
| 标准 PBR opaque/alpha-mask | Deferred；保留贴图、法线、金属/粗糙度、自发光、双面、clipping 与遮罩轮廓 |
| skin/morph/CPU 及外部 GPU instance | 使用一致位置/法线/覆盖；已有受支持组合继续有效；不把 InstancedToon 的原 no-shadow 限制扩成新承诺 |
| PBR clearcoat/sheen 等扩展 | G01 冻结逐项覆盖；可通过 Forward 专用 pass 保持已有语义，不允许直接丢掉扩展通道 |
| Blinn-Phong/Toon/自定义及特殊材质 | 允许继续 Forward，明确每种材质的灯光能力；受限材质显示原因，不伪装成已支持百灯 |
| 透明 PBR | 混合 Forward 与共享深度；至少有完整灯表参考路径保证 128 灯正确。不得使用仅由 opaque 深度截断的 tile 列表；排序、混合、深度写入遵守既有合同 |
| 方向光阴影与环境 IBL | 保留已有受支持数量与质量，阴影索引/材质接收语义不变；局部灯无阴影需明确 |
| AO/雾/HDR/曝光/色调映射 | 在正确空间按现有语义应用一次；AO 不无条件乘全部自发光与直接光，输出不重复编码 sRGB |
| TAA/运动模糊/轮廓/RTT/平面反射 | 按现有覆盖与历史合同验证；反射等子视图可选择 Forward，但必须说明容量与回退，不能共享主相机 tile/history |

对未支持组合提供运行时可见原因及完整 Forward 回退。若回退仍受 8 灯上限，必须明确显示覆盖不足；不得把这种场景纳入“完整多灯兼容”的通过项。后处理取样何种表面需用前后景用例验证，不能简单以 opaque 深度覆盖原有透明辅助表面。

## 资源与 API 所有权

- 复用 Render3DFramePlan/RenderGraph、现有 target pool、frame ring 与 recovery participant；共享 source、per-view G-buffer/list、temporal history 分别有唯一 owner。
- resize、DPR、视图删除、profile 切换、device lost 后不复用旧 device 句柄；在途资源按提交生命周期退休。缓存有上限、可诊断、可释放。
- WebGPU attachment 数量/每像素字节数、纹理格式/用法、storage 大小、stage limits 和 compute workgroup 均按实际 device 检查；optional timestamp 不作为基础渲染的硬依赖。
- 稳定 root 保持现有 golden path。公开配置以一个 coherent profile/capability 表达；G01 先审查实验子路径与迁移方式，再由串行 owner 集成。
- 帧内统计与非阻塞 timestamp 进入现有诊断；逐像素 oracle/readback 仅在测试/显式调试时运行。

## G05 private AO storage integration — 2026-09-28

The serial integration owner admits an atomic private AO representation revision to address the measured allocation failure ([review](../../../Engine/review/engine-0.2.1/g05-ao-memory-budget-review.md)). Store the same red half-float visibility in R16F and packed storage words; retain the existing storage bindings and lighting semantics. G-buffer/light ABI, public options, sampled-texture count, quality and frozen budgets remain unchanged. A shared device allocation ledger charges live and pending Deferred targets; joint AO/tile planning may use the existing same-frame full-list fallback for unstored tiles, with explicit counts and separately measured costs. This is implementation authorization within G05, not acceptance of unimplemented behavior or completed verification.

## G05 private point evaluation integration — 2026-09-28

The serial owner admits arithmetic specialization in `point-resolve.wgsl` for the measured high-overlap and AO full-list fallback GPU costs. Keep the independent reference shader, tile/light ABI, accepted BRDF, full coverage, quality, workloads and budgets unchanged. Native pixel and boundary oracles must pass before performance qualification.

The two initial arithmetic trials were archived and rejected; the original point evaluator was restored before full-sample qualification. Their pixel smoke results do not constitute a performance acceptance. See `Engine/review/engine-0.2.1/g05-gpu-arithmetic-experiments.md`.

## G05 point source binding integration — 2026-09-28

Admit a private uniform alias over the existing source buffer (header plus 255 records, 16,336 bytes). The original source storage binding and ABI remain intact; higher source indices read storage. No additional allocation or upload is permitted. CPU buffer usage, fragment reflection and consumer bindings move atomically, including zero lights, 255-boundary, 1024 lights, pending submissions and both native adapters. This is an experiment authorization, not a performance acceptance.

The uniform-alias experiment also passed native correctness but did not establish the required Intel performance improvement. Its source/bundle/evidence were archived and the alias was removed. Final qualification again uses the unchanged source/storage ABI and original arithmetic.

## G06 示例公共入口集成 — 2026-09-29

为实现用户优先要求的多灯示例，串行 owner 将最小 experimental profile facade 的 API 评审前移至 G06：复用现有 `@haiyue/engine/experimental/renderer`，提供显式异步初始化、只读诊断及主动调试读回，不导出原始后端或 GPU 资源。stable root、包路径、版本、ABI 和性能预算不变。G07 仍负责最终 clean candidate/package 验收。

## G09 FrameGraph 规划约束 — 2026-10-01

新增 [G09](goals/g09-framegraph-optimization.md)沿用 RenderGraph 逻辑编译、RenderPipeline 执行和既有资源 owner 的职责。实施前通过新 ADR 冻结副作用根、资源版本/描述符、观察者、物理复用及缓存失效合同；本段不修改已接受 ADR 或授权改动光照/Shader ABI。

生命周期复用不得提前销毁 pending GPU 资源；历史、外部 RTT、readback 必须显式保留。WebGPU 范围内优先实现兼容对象复用，不以 native heap aliasing 或多队列调度名义承诺收益。默认 Forward、画质/灯光完整性、原性能和包体门禁不变。当前只批准目标规划，未来实现状态由机器计划和明确启动记录确定。
