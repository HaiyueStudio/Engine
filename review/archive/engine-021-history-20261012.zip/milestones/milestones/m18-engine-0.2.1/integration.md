# 集成、验收与发布边界

## 硬件合同修订 — 2026-10-06

用户明确批准调整合同并继续 G09。按 [ADR 0117](../../../Engine/docs/for-ai/adr/0117-native-021-hardware-scope.md)，必需验收采用一条完整原生路径：Windows 独显 Chrome＋Edge，或 macOS Apple Silicon/AMD Metal Chrome。旧 Intel Gen9 集显为非阻塞 extended 兼容；保留原失败，不宣称已修复。原质量、场景、独显性能/内存预算和 3×300 CPU/GPU、120 帧预热、实测 120 秒冷却均不变。新主机重新建立同机基线；G09/G05 未因范围修订完成，G07 仍依赖其完整证据。以下早期双设备检查点保留为历史。


## 所有权和状态

初始顺序为 G01 → G02 → G03 → G04 → G05 → G06 → G07。用户于 2026-09-29 调整为先执行 G06（依赖已完成的 G04），G05 仍未通过；G07 必须同时通过 G05、G06。2026-10-01 用户新增 G09 为 0.2.1 必做目标，G07 现同时依赖 G05、G06、G09；G09 直接依赖 G04/G06，不等待 G05 已有性能卡点解决。G09 已启动依赖与裁剪子阶段，实施后在最终候选重跑 G05，共享运行时代码与采样必须串行。G08 独立规划跨引擎对照及设备分档，不修改既有发布门禁。依赖完成后，集成 owner 才将下一 Goal 从 draft 调整为 ready。机器索引由同一串行集成 owner 更新；叶 Goal 不自行扩大写入范围或改发布基线。

写入范围在 `milestone.json` 中以 HaiyueStudio 为相对根。G01 冻结 ABI/profile/设备与预算，G02–G06 与 G09 在合同内实现，G07 集成候选、公开导出和正式证据。共享模块需要变更时先同步合同并回归已有 Goal，不另造并行数据所有者。

## 验收矩阵

| 组 | 必测场景 | 通过条件 |
| --- | --- | --- |
| A：灯光正确性 | 0/1/8/9/32/128/256 点光源；方向/环境混合；逐灯启停、颜色/半径/运动变化 | 9 灯边界不截断；128/256 完整覆盖；像素结果与全灯参考在冻结容差内，灯 ID 和统计守恒 |
| B：剔除 | 稀疏/高重叠/全部灯覆盖同一 tile，边界相交、近裁面、相机在球内、空 tile、正交/透视 | CPU 几何 oracle 无漏灯，Tiled 与全灯参考一致；强制小容量测试溢出回退本帧正确 |
| C：兼容 | 标准/扩展 PBR、mask/透明前后景、skin/morph/实例、三方向光阴影、IBL、AO/雾、TAA/运动模糊、outline、RTT/反射 | 材质矩阵逐项有真实画面/像素断言；回退原因明确；无重复阴影、曝光或颜色转换 |
| D：生命周期 | 单/四视图、不同 layer/viewport、resize/DPR、profile 反复切换、视图销毁、device replacement | 数据不串视图，WebGPU validation errors=0；至少 300 次切换后 owner residual=0，资源高水位有界；真实设备恢复与注入测试分开标注 |
| E：规模性能 | 1/8/128/256 灯、稀疏/高重叠、静态/动态、720p/1080p、1/4 视图 | 保留完整同工作量和同质量证据；小场景不回退，多灯满足 G01 冻结预算 |
| F：现有实例 | 1k/10k 实例、LOD on/off、遮挡少/视锥剔除多、单/四视图 | 唯一 ID/姿态/法线/LOD 正确；配对 CPU/GPU/upload 数据；正常帧不做全量实例读回 |
| G：压力诊断 | 512/1024 灯、1080p、全重叠、容量不足/低 limits | 报告耗时与资源，不承诺统一帧率；无非法 GPU 访问或静默画质降级 |

G01 将此矩阵落成命名 case：A/B/C/D 全覆盖；E/F 所选设备至少含 small-8、sparse-128、overlap-128、sparse-256、dynamic-128-four-view、1080p-128、instances-1k、instances-10k。不得后选表现好的 case 代替原集合。复用 Engine 仓内真实场景 fixture，并增加固定种子的多灯房间/走廊和实例场景；不把兄弟 Games 仓作为构建依赖。

## 测量方法与预算

- 必需硬件：完成上述一条完整平台路径；旧集显/移动 GPU 为扩展兼容，记录 OS/browser/backend/adapter/limits。Mac 型号不同但同 GPU 类不自动视作两类。iPhone/Android 的支持声明需要对应真机数据，不能由桌面模拟推导。
- 同一场景、相机轨迹、灯光分布、分辨率/DPR、材质/阴影、seed 与 candidate revision。先测旧 Forward 小灯基线，再测全灯 Deferred reference 与 Tiled；旧 Forward 丢灯场景只作画面/容量展示，不参与等价工作量加速比。
- G01 已冻结每 case 预热 120 帧、3 轮交错顺序、每轮 300 CPU/300 GPU 样本，场景间固定空闲 30 秒；保存所有样本与失败原因。固定 Mac 主机的采样前后必须通过 speed/scheduler limit 100 检查。冷启动/pipeline 创建单独采样，不混入稳态。若既有正式协议更严格，沿用更严格协议。
- 分开报告 CPU prepare/record、GPU 各 pass/整帧 timestamp、frameWall、上传次数/字节、draw/pass/dispatch、pipeline 创建、纹理/buffer 估算字节及资源高水位。frameWall 和 FPS 不称为 GPU 时间；估算 allocation 不称为实际驱动显存驻留。
- timestamp 不可用时渲染仍应工作，GPU 时延字段写 unavailable；要完成 GPU 性能资格需补足支持 timestamp 的设备，不用 CPU 时间代填。

以下目标已在 G01 冻结进 [Engine 配置](../../../Engine/config/lighting-performance-021.json)；已有更严格 gate 保持。不可在实现后为通过而换设备、删慢样本、调低画质或扩大阈值。两项用户批准的 G01 亚毫秒实例基线绝对上限保留相对波动说明，仅适用于其具名夹具/设备/通道，不扩散到其他性能案例。

| 指标 | 规划目标 |
| --- | --- |
| 关闭 Deferred 的小场景 | CPU/GPU P95 相对同机基线回退 ≤5%；Deferred 专用目标/列表分配为 0 |
| 稀疏 256 灯 | Tiled 的 cull+lighting GPU P95 比全灯 reference 至少降低 20%，同时报告全帧 P95；若未达标则优化或显式评审，不宣称性能目标完成 |
| 高重叠 128 灯 | 相对全灯 reference 的整帧 GPU P95 额外开销 ≤10%，或采用正确的低收益回退并证明预算；不以漏灯换耗时 |
| 128/256 灯 720p 单视图 | 用户确认独显 60 fps、集显 30 fps；CPU/GPU P95 为 4/12 ms 与 8/24 ms，完整帧另受 1000/60 与 1000/30 ms 上限约束。四视图/1080p 逐项预算见配置，当前不宣称已达到 |
| 内存/上传 | G01 冻结 B/pixel、灯表/索引上限与每视图内存预算；稳定帧无 Deferred 专属新建 GPU buffer/texture，静态灯不全量重复上传 |
| 包体/Shader | 逐入口记录新增 shader 字节、variants/pipelines、冷编译、gzip；普通消费者不带入 Deferred family，原预算保持，新额度必须有能力归因评审 |

Deferred G-buffer 的带宽和透明 Forward 开销必须包含在整帧结论中；不能只展示 light resolve 的局部收益。GPU 实例先测量再优化，不预设每个 case 必须提升固定倍数。

## 证据与完成条件

Engine 下新增候选报告建议放在 `artifacts/engine-0.2.1/`；正式归档遵循现有 release 工具的规范路径。报告带 revision、dirty、输入与 shader hash、设备、命令、原始样本、画面及 scope。每个 Goal 的简短交接放在 `review/engine-0.2.1/`，文档引用权威 artifact，不复制随时变化的数值。

G07 必须在同一 clean revision 重跑：

- 新增 Deferred 正确性/溢出/多视图/恢复专项、GPU 实例验证和所选完整平台路径的性能矩阵。
- `npm run check:engine:fast`、`npm run check:engine:slow`、`npm run verify:engine-package`、`npm run release:no-rive`，以及纳入新门禁后的 `npm run release:check`；按正式入口避免无意义重复构建。
- 生产 Shader 再生成一致性、现有 API/export 及消费端预算、完整自动 examples 范围、干净安装和 no-publish rehearsal。示例构建成功不代替浏览器效果验收。

发布资料包括能力/限制、实验 API、材质覆盖、设备资格、Forward 回退和容量诊断、示例操作、已知问题、包哈希、升级/回滚说明。新增规模化能力的 ADR/策略必须与证据一致；CSM/局部灯阴影仍单独 hold。

第二类设备缺失、完整灯光有漏算或 GPU 性能资格未完成时保留 validating/blocked 的真实状态，不把 diagnostic 记为正式通过。Engine 发布不执行 UI/Editor/Games 门禁，也不要求其升级；协调仓的版本政策仅在实际消费兼容性有证据时由串行 owner 更新。候选准备完成不包含 npm 发布操作。

## G09 FrameGraph 专项验收 — 2026-10-01

以 [G09 计划](goals/g09-framegraph-optimization.md)的资源覆盖、真实活跃根、兼容物理复用、导入导出/历史/读回、计划缓存失效及两设备 A0/B4 对照为新增必做项。分阶段消融只作归因，最终以旧生产版本与完整候选的同画质整帧比较为准。

G09 产物须证明至少一项真实生产收益，且无新增不合格退化；20% 瞬态峰值和 10% CPU 降幅是待基线评估的探索目标，不是现有成绩或放宽旧预算的依据。G07 在同一 clean candidate 验收 G09 入口及 G05 的全部原有资格，不能拼接旧版本与新版本的通过项。G08 跨引擎/设备分档研究保持独立。


### G09 依赖与裁剪检查点 — 2026-10-01

已实现本次授权的读写依赖与步骤裁剪；见 [子阶段审计](../../../Engine/review/engine-0.2.1/g09/dependency-culling-audit.md)。结构收益和像素正确性证据属于 dirty 开发候选，不替代 G09 的最终 A0/B4 性能对照，也不提升 G05/G07 状态。


### G09 临时纹理复用检查点 — 2026-10-01

资源映射、提交隔离与 Deferred/AO/后处理复用已实现，详见 [审计](../../../Engine/review/engine-0.2.1/g09/resource-reuse-audit.md)。最终开发矩阵通过与先前失败分别保留；集显像素偶发没有宣称修复，不能仅选最后一轮提升为发布稳定性凭据。G09/G05/G07 状态不提升。

### G09 计划缓存与附件操作检查点 — 2026-10-02

阶段四实现及双 GPU 专项（含 MSAA、混合尺寸四视图）已验证，见 [审计](../../../Engine/review/engine-0.2.1/g09/plan-cache-audit.md)。修复了新对照发现的 Outline resize 提前释放。完整矩阵仍在 Intel 原有复用夹具出现空画面/像素差异；失败保留，完整兼容性及持续稳定性未通过，G09/G05/G07 状态不提升。

### 阶段六执行检查点 — 2026-10-02

已接入图/资源策略、原生兼容性及示例回归；不授予正式性能资格。A0/B4 对照诊断暴露集显全黑或 1 像素覆盖，旧版与候选均有失败证据。新增完整覆盖和整幅图配对断言，保留最初漏判及重新判定的原始资料；详见 [审计](../../../Engine/review/engine-0.2.1/g09/comparison-regression-audit.md)。

按冻结合同暂停性能采样。F0–F8 完整矩阵预注册、分段 CPU/GPU 统计、三轮 A0/B4 及消融性能人口、同候选性能证据的发布消费仍未完成；不得把本次小尺寸定位实验或最后一次回归通过替代它们。G09 状态保持 active。
