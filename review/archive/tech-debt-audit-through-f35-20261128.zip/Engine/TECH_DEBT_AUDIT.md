# Engine 技术债审计

复审日期：2026-11-28。使用本机 [tech-debt-audit](C:/Users/Administrator/.codex/skills/tech-debt-audit/SKILL.md)，审查 **D:/HaiyueStudio/Engine 当前工作区**：HEAD `a8b7ae6` 加已有修改，包含 GUI P0–P3。随后按用户请求修复 F27–F35；其他问题、既有改动、API、依赖及预算保持。

## 执行摘要

- **F01–F35 均为 RESOLVED；本轮已确认问题没有未处理项。** 本轮没有确认 Critical／High 问题，不能据此推断未审路径没有问题。
- F30 按已解析类型判定时间依赖；F31 复用原录制资源 owner 保留材质及关联资源；F32 在异步发布前验证缓存代次。没有新增公共运行时或公开符号。
- F27–F29 复用原组件清理、命中与活动时钟：销毁取消数字框草稿，复合 hover 包含子树与关联子菜单，自动弹层构造失败归还借用和订阅；20 项回归及 16 项真实浏览器交互通过。
- F33–F35 共用浮点格式化规则、补齐原 HYA owner 的异常清理，并在 QR 构造前校验初值；31 项回归和 12 组双后端真实编译通过，没有新增公共运行时或公开符号。
- F30–F32 新增 **20 项回归、12 项像素策略检查全部通过**；真实 NVIDIA GPU 的 **50 项完整 RGBA 对照最大通道差 0**，GPU 错误、缓冲／纹理残留、此次浏览器进程残留均为 0。原始缺陷在同一夹具中被分别捕获。
- 工作区边界、601 个 Engine 模块边界、公共 API、文档检查及文档／归档策略 **32／32** 通过。经用户明确授权，npm 官方只读 audit 报告 **0 项已知漏洞**。
- 修复验证与原审计证据分别保留，原失败不覆盖；正式压力采样、Mac／iPhone 交互、发布演练均不在本次范围。
- 旧报告 61,994 B 已压为 24,612 B 的[历史 ZIP](D:/HaiyueStudio/Engine/review/archive/tech-debt-audit-through-20261126.zip)，完整解压回读一致；[清单](D:/HaiyueStudio/Engine/review/archive/tech-debt-audit-through-20261126.json)保留原路径与 SHA-256。下文只保留现行问题、方法和结论。

## F33–F35 修复结论

| ID | 状态 | 方法与结论 |
| --- | --- | --- |
| F33 | RESOLVED | 两后端共用私有 [floatLiteral.ts](D:/HaiyueStudio/Engine/shader-language/src/backend/floatLiteral.ts:1)，科学记数法不再在指数后追加小数点；普通整数、负零、分数、各后端后缀及原有限数校验保持。公开 Material Graph、标量和向量对照通过。 |
| F34 | RESOLVED | [Animation2DRuntime.ts](D:/HaiyueStudio/Engine/extensions/src/animation/Animation2DRuntime.ts:1) 共用正常销毁与扩展创建失败的回滚入口。先失效再逐项释放句柄、字体、文字、音频、扩展和节点，清空索引；未挂树的节点同样销毁。清理错误最终聚合，创建错误仍保留为首项；无清理错误时重抛原对象，迟到句柄只释放。 |
| F35 | RESOLVED | [QRCode.ts](D:/HaiyueStudio/Engine/extensions/src/gui-assets/QRCode.ts:1) 在取得组件资源前同步校验初值，复用原 8,192 UTF-16 单元上限；显式 setValue 的非法输入仍由调用者 await 拒绝。合法初值、适配器错误反馈、latest-wins 和销毁取消保持，严格未处理拒绝模式通过。 |

[17 项数值回归](D:/HaiyueStudio/Engine/shader-language/test/numeric-literals.test.mjs:1)、[8 项 HYA 清理回归](D:/HaiyueStudio/Engine/extensions/test/animation-runtime-cleanup.test.mjs:1)、[6 项 QR 初始化回归](D:/HaiyueStudio/Engine/extensions/test/qr-initialization.test.mjs:1)及 11 项编译验收策略检查通过。[真实原生 GPU 编译](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f33-f35/native-v1/result.json)的 12 组 WGSL 管线与 GLSL 编译／链接全通过，三种旧错误语法两端均拒绝，正例 GPU 错误及浏览器／GL 对象残留为 0。原源码、旧生成缓存／Stage 14 报告和失败记录保留于同级 before/ 与独立日志；生成物使用只读校验，没有手改。

本批全仓类型检查、构建和 **3,010 项测试**通过，失败／跳过／取消为 0；116 个构建目标新鲜度匹配。Shader Language 完整检查及 Stage 14 的 **25／25 节点**通过，双后端像素差异为 0，原成本与画质预算保持。最终字节清单、生成物／旧修复保护结果见 [completion.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f33-f35/completion.json)。

## F27–F29 修复结论

| ID | 状态 | 方法与结论 |
| --- | --- | --- |
| F27 | RESOLVED | [InputNumber.ts](D:/HaiyueStudio/Engine/extensions/src/gui-forms/InputNumber.ts:1) 的内部提交回调遵守 owner 失效保护。销毁取消未提交草稿且不触发 onChange，正常存活 blur 仍只提交一次；保留 Composite 先失效再清理的重入保护。 |
| F28 | RESOLVED | [hover.ts](D:/HaiyueStudio/Engine/extensions/src/gui-common/hover.ts:1) 共用可见子树 hover 判定；Popover 包含 anchor、内容及显式关联子菜单，离开后才启动原 120 ms 关闭活动，稳定悬停取消活动。Carousel 在实际子控件悬停时暂停，离开后按原时钟恢复。Engine 命中、事件归属和冒泡合同保持。 |
| F29 | RESOLVED | [overlay.ts](D:/HaiyueStudio/Engine/extensions/src/gui-overlays/overlay.ts:1) 在借用前验证 trigger／anchor，取得 frame、part 绑定、root 及 anchor 监听后立即登记回滚；安装失败、构造中 root 销毁和清理异常均归还独立资源并保留原错误。Popover、Dropdown、Popconfirm 一致。 |

新增 [20 项源码回归](D:/HaiyueStudio/Engine/extensions/test/gui-lifetime-hover.test.mjs:1) 与 [7 项验收策略检查](D:/HaiyueStudio/Engine/scripts/webgpu-gate/gui-lifetime-hover-policy.test.mjs:1)。[真实 Chrome／原生 GPU 交互](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f27-f29/native-final-visible/result.json)覆盖实际鼠标、键盘、触摸、自定义样式和共享宿主子菜单，16／16 通过，GPU 错误、资源、订阅及所属浏览器进程残留均为 0；[截图](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f27-f29/native-final-visible/hover-children.png)保留实际画面。[修复前包的同夹具对照](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f27-f29/native-before-visible/result.json)捕获全部原问题，轮播使用连续切页计数，防止切回原页掩盖故障。原源码与失败记录保留在同级 `before/` 和独立日志中。

最终全仓类型检查、构建与 **2,979 项测试**通过（失败／跳过／取消均为 0）；116 个示例及共享构建目标的新鲜度、工作区／601 模块边界、公共 API 和文档检查通过。2,244 份最终输入及原 F30–F32 的 14 份实现／工具逐项哈希复核，详见 [completion.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f27-f29/completion.json)。

## F30–F32 修复结论

| ID | 状态 | 方法与结论 |
| --- | --- | --- |
| F30 | RESOLVED | [CoreTimelineDependencies.ts](D:/HaiyueStudio/Engine/extensions/src/animation/production/CoreTimelineDependencies.ts:1) 明确检查组件、节点 effects 与 compact／stack composite 的轨道；替代递归字段名猜测。legacy morph、opacity、expansion 在无其他轨道时推进及反向 seek 正确，真正静态 core 仍只采样一次。 |
| F31 | RESOLVED | [ToonRenderer.ts](D:/HaiyueStudio/Engine/engine/src/renderer/ToonRenderer.ts:1) 复用 RecordedGpuResources，按未提交引用对材质缓冲 COW，bind group、纹理 handle、默认纹理、阴影及灯光对象随提交／取消／fence 退休。纹理请求有独立代次。真实像素覆盖正反提交顺序、取消后淘汰及 renderer 销毁后提交；最后一项先清空目标，防止旧画面掩盖未执行的命令。 |
| F32 | RESOLVED | [BaseRenderer.ts](D:/HaiyueStudio/Engine/engine/src/renderer/BaseRenderer.ts:1) 在贡献 warmup 时捕获缓存代次，启动与 await 返回时都检查；render／compute 一致。旧编译继续完成并结算原诊断，但不再回写新缓存。BitmapText 实际 renderer 的 CPU 回归及两个真实 GPUDevice 的 render／compute 像素对照通过。 |

定向回归见 [green-final.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f30-f32/green-final.json)；[最终原生结果](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f30-f32/native-final/result.json)绑定产品、夹具及构建字节，完整 128×128、1×／4×MSAA、零通道差检查。独立 Chrome 清理检查通过。[修复前反例](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f30-f32/native-before-final/result.json)只替换保存的三份原源码，HYA／Toon／旧设备管线分别失败；这些失败保留原判定。

全仓类型检查、构建与 **2,959／2,959 测试通过，0 失败／0 跳过**；其中包含本次新增的 20 项运行时回归，另有 12 项像素策略检查。模块／工作区／API／职责边界及同步 prepare 合同通过。首次全仓尝试因沙箱拒绝既有路径逃逸测试创建临时 symlink 而停止，原失败保留；获得本机权限后原样运行通过，没有跳过或放宽该用例。

可重复入口：在 Engine 根目录运行 `node scripts/verify-tech-debt-f30-f32.mjs`。该入口创建独立 artifacts 目录，检查全部 50 个具名对照、所有像素、原生 GPU 身份和资源残留；不修改正式基线或预算。Windows 若需创建符号链接／核查捕获进程，应在具备相应权限的终端运行。完整验证、范围及逐文件 SHA-256 见 [修复凭据](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f30-f32/completion.json)。

## 架构模型与审查依据

Engine 管理 Scene／ECS、输入域、GPU 录制、提交与退休；Extensions 通过公开入口组合可选 GUI、动画、音频及视觉小说能力。animation-spec 管理来源无关的格式与输入边界，shader-language 在构建期完成图／DSL 到 Typed IR 和着色器的转换。新增 GUI 组件复用原布局、编辑器、焦点、活动时钟及渲染器，应用内容通过借用租约挂载。

值得统一的是这些既有机制的使用规则：时间依赖必须完整，异步结果必须验证所属代次，录制中的资源必须保留，构造与清理必须覆盖失败路径。没有证据支持为了文件规模而拆分运行时，也不能将“节点／文字／动画”名称相近视为重复实现。本轮没有确认新的常态性能复杂度退化；下列 GPU 与时间缓存问题首先是正确性问题，不附带未经测量的 FPS 收益。

重新读取了 README、各 workspace manifest、仓库地图、API 边界及 AGENTS；保存最近 200 条提交及六个月变更。排除生成物、vendor、构建 bundle 后，统计为 **2,219 份源码／工具／示例文件，302,930 行**；四个基础 workspace 的 src 为 1,241 份、189,021 行。物理行数不是运行时成本，不与旧报告不同筛选口径直接比较。[orientation.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/orientation.json)保存筛选结果、源码哈希、前 20 大文件、前 20 高 churn 文件及交集；重点交集是 Animation2DRuntime、Animation2DRenderSystem、GuiSystem。

## 新发现

下表保留审计时的问题与建议；**F27–F35 已修复，现行方法与证据见上表**。S＝局部修正及定向回归；M＝涉及多个生命周期或消费路径，需要集成对照，并非工时承诺。

| ID | 类别 | File:Line | 严重度 | 工作量 | 问题、触发与影响 | 具体建议 |
| --- | --- | --- | --- | --- | --- | --- |
| F27 | GUI 销毁／内部重入 | [InputNumber.ts:16](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f27-f29/before/extensions/src/gui-forms/InputNumber.ts:16)、[composite.ts:65](D:/HaiyueStudio/Engine/extensions/src/gui-common/composite.ts:65) | Medium | S | 数字框有焦点并含未提交文本时 dispose：Composite 先置 dead，再 blur；内部 commit 回调再次调用 alive，抛 disposed LayoutError，最终报告 AggregateError。实证元素已摘树，但正常关闭仍报错，值停在 1 而未提交的文本为 2；未聚焦关闭正常。 | 销毁时取消／解绑内部 blur commit，或在 owner 失效后直接返回；保留普通存活 blur 的提交。不要将其误归因为应用观察者抛错。 |
| F28 | GUI 命中／子树悬停 | [overlay.ts:80](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f27-f29/before/extensions/src/gui-overlays/overlay.ts:80)、[Carousel.ts:12](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f27-f29/before/extensions/src/gui-content/Carousel.ts:12)、[GuiSystem.ts:742](D:/HaiyueStudio/Engine/engine/src/gui/systems/GuiSystem.ts:742) | Medium | M | GuiSystem 只更新直接命中对象；复合组件却用容器 hovered／enter 判断整个子树。鼠标移至 Popover 内按钮后，子按钮 hovered=true、panel=false，200 ms 后弹层关闭；Carousel 内输入框 hovered=true 时，250 ms 自动播放仍在 300 ms 切页。 | 在复合控件层共用子树 hover 判定，同时用于关闭倒计时与 autoplay。参考 notification 的现有子树扫描；不要改变 Engine pointerenter 的归属／冒泡合同。 |
| F29 | GUI 构造／借用回滚 | [popover.ts:4](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f27-f29/before/extensions/src/gui-overlays/popover.ts:4)、[overlay.ts:37](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f27-f29/before/extensions/src/gui-overlays/overlay.ts:37)、[overlay.ts:77](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f27-f29/before/extensions/src/gui-overlays/overlay.ts:77) | Medium | S–M | click trigger 缺 anchor 时，super 已挂载 content、取得 frame 并订阅 root，随后 bindTrigger 才拒绝；派生构造没有回滚。连续三次失败留下 3 个订阅，摘下 content 后仍无法重新借用，直至 root 销毁。manual trigger 无 anchor 的合法对照正常。 | 获取资源前验证 trigger／anchor；获取后发生的任何失败均清理已取得租约和订阅。顺查其他自动 trigger 派生构造，本次实证限定 Popover。 |
| F30 | HYA 失效／时间分类 | [ProductionCoreStateVisualRuntime.ts:50](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f30-f32/before/extensions/src/animation/production/ProductionCoreStateVisualRuntime.ts:50)、[早退:86](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f30-f32/before/extensions/src/animation/production/ProductionCoreStateVisualRuntime.ts:86)、[分类:221](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f30-f32/before/extensions/src/animation/production/ProductionCoreStateVisualRuntime.ts:221) | Medium | M | 分类只扫描 components 并依赖字段名，遗漏 legacy path morph 的 times/values，以及 node.effects.opacityTrack、node.composite.expansionTrack。无普通 transform track 时，生产 core 只求值一次：t=0.5 时 morph x 仍 0（应 5）、opacity 仍 1（应 0.5）、expansion 仍 0（应 5）。公开 HYA player 也复现。 | 根据已解析类型完整判断时间依赖，继续调用原采样器；真正静态文档仍早退。覆盖无附带 transform track 的推进、seek 和反向恢复，不能靠添加无意义轨道唤醒缓存。 |
| F31 | GPU 材质／待提交录制 | [ToonRenderer.ts:397](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f30-f32/before/engine/src/renderer/ToonRenderer.ts:397)、[释放:538](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f30-f32/before/engine/src/renderer/ToonRenderer.ts:538) | Medium | M | Toon 材质直接覆写同一 uniform buffer，淘汰时立即 destroy。真实 renderer／RenderFrameContext 加共享审计设备中，两个未提交 context 共用 buffer #29，先写红再写绿；两者 submitted=false 时淘汰已销毁它。初审结构证据说明旧录制没有保留自己的资源版本；本次已补齐真实像素对照，结果见修复结论。 | 让 Toon 材质加入既有 RecordedGpuResources，发生写入时按录制引用决定 COW，纹理替换和淘汰使用既有退休规则。补旧／新帧交错 submit、cancel 及退出后的资源对照。 |
| F32 | 异步管线／设备代次 | [BaseRenderer.ts:114](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f30-f32/before/engine/src/renderer/BaseRenderer.ts:114)、[compute:185](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f30-f32/before/engine/src/renderer/BaseRenderer.ts:185) | Medium | M | warmup await 后只检查缓存有无 key，没有检查 renderer 生命周期。device A 预热 pending→取消 plan→destroy／prepare device B→A 迟到完成，plan 状态虽 cancelled，A 的管线仍写入新缓存。BitmapTextRenderer 实证命中旧 shader，B 创建管线数为 0。compute 同样缺少代次检查，实证限定 render。 | 缓存清空／重建时更新 epoch，异步创建捕获 epoch 和 device，发布前确认仍有效。取消后等待不可中止的编译结束是合理行为，问题在于过时结果仍发布。 |
| F33 | 编译器／数值输出 | [wgsl.ts:313](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f33-f35/before/shader-language/src/backend/wgsl.ts:313)、[glslEs300.ts:464](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f33-f35/before/shader-language/src/backend/glslEs300.ts:464) | Medium | S | 对 Number.isInteger 的值一律追加 .0；1e21、-1e21、1e30 仍在 f32 有限范围，却输出 1e+21.0f 等非法 token，公开图编译返回 ok:true。实际 WebGPU 对三个 token 均报语法错误；1e+21f、1e-7f 对照无编译错误。 | 两后端共享明确的数值格式化规则：已有 e/E 时不能再在指数后补 .0，保留各后端后缀及有限数合同；补科学记数法边界与真实编译检查。 |
| F34 | HYA 扩展／异常清理 | [Animation2DRuntime.ts:283](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f33-f35/before/extensions/src/animation/Animation2DRuntime.ts:283)、[destroy:414](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f33-f35/before/extensions/src/animation/Animation2DRuntime.ts:414) | Low | M | 已注册扩展 destroy 抛错，会跳过后续扩展、节点索引清空及 runtime root 销毁；destroyed 已置位，重试不能补偿。实证剩一个活动扩展、两个 nodes 和一个挂载子树。初始化失败叠加回滚错误还覆盖原错误。限异常路径，非正常使用必然泄漏。 | 构造回滚与销毁共用私有清理执行器，逐项尝试并最终聚合原始／清理错误；提前失效防重入仍保留。补多扩展异常及初始化失败叠加回滚对照。 |
| F35 | QR 初始化／异步错误归属 | [QRCode.ts:12](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f33-f35/before/extensions/src/gui-assets/QRCode.ts:12)、[校验:16](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/f33-f35/before/extensions/src/gui-assets/QRCode.ts:16) | Low | S | constructor 以 void 调用 async setValue；其初始值长度校验位于 try 之外。传入 8,193 字符时 constructor 返回实例且不抛错，随后产生 unhandledRejection；默认 Node 策略可能终止宿主。合法初值正常 Ready，无未处理拒绝。 | 初值在取得资源前同步校验，或显式拥有并处理初始化 Promise。后续显式 setValue 的拒绝仍由调用者 await；不能只在全局吞掉 rejection。 |

## 审计建议与实施边界（以下五项已完成）

1. **F30：以解析类型判定时间依赖。** 为 core 定义私有纯函数，明确覆盖 node effects、composite、legacy morph 和现有组件轨道。缓存键继续由原 owner 生成；复现中的无关常量 position track 只作为反例，不作为修复。成功标准是三类动画与普通 runtime 一致、静态文档仍只求值一次。
2. **F31：补全 Toon 的录制所有权。** 复用现有 RecordedGpuResources／退休回调，不再由材质 map 直接决定 GPU 生命周期。旧 context 尚在录制时替换材质，应保留旧 buffer／纹理；新 context 使用新版本。验证两个提交顺序、单独取消和最后 fence 后归零。
3. **F32：异步管线发布校验 epoch。** render／compute warmup 捕获生命周期身份，await 完成后验证再写缓存或 store；无效结果不影响新代次缓存及诊断。验证取消、destroy、设备切换、相同 key 并发及新设备同步回退；不要求 GPU API 支持真正中止编译。
4. **F27＋F29：统一组件取得资源和失效后的回调规则。** 内部 blur 回调不得提交到已销毁 owner；构造失败必须归还已取得的 frame／订阅。沿用 Composite／Overlay 的现有清理入口，避免增加第二个组件 owner。测试要覆盖实际聚焦、自动 trigger 和借用节点再次挂载。
5. **F28：明确复合控件 hover 的范围。** 共用一个只读子树判定供 popup 和 autoplay 使用，仍由原 GuiSystem 更新直接命中状态、原活动时钟推进。验证 anchor→子按钮→外部、子输入框及嵌套控件；不能仅在测试中手动把 panel.hovered 设为 true。

F33–F35 已按上表完成，失败路径和原有成功路径均有对照；本轮未测得可量化性能增益，不据此调整预算。

## 原审计证据（修复验证见上）

| 范围 | 本轮结果 | 凭据 |
| --- | --- | --- |
| GUI 焦点销毁、构造回滚、实际路由 hover＋原时钟 | 预期缺陷断言重现；有未聚焦、manual trigger 等反例 | [gui/results.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/gui/results.json)、[probes.mjs](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/gui/probes.mjs) |
| HYA legacy morph 与普通 runtime／公开 player 对照 | 生产路径静止，无关常量 track 可唤醒；另外两种节点轨道也漏采样 | [legacy-morph.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/animation/legacy-morph.json)、[time-and-cleanup.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/animation/time-and-cleanup.json) |
| Toon 录制、取消 warmup 后设备重建 | 共享审计 GPU＋真实 renderer／context 的结构复现；不代表真实像素或设备资格 | [toon-recording.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/core/toon-recording.json)、[warmup-generation.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/core/warmup-generation.json) |
| 大数值着色器 | 当前源码生成非法 token；实际 WebGPU 编译验证 token 的语法错误 | [float-literal.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/core/float-literal.json)、[编译消息](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/core/float-literal-native-compilation.json) |
| QR 初值 | 当前 P3 入口重新严格转译；子进程记录未处理拒绝，合法初值 Ready | [p3-results.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/p3-results.json) |
| 独立复核、静态门禁 | 七个复核进程 exit 0；边界／API／文档与 32 项策略检查通过 | [recheck.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/recheck.json)、[checks.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/checks.json) |
| 依赖 | 经明确授权查询 npm 官方 registry，exit 0，已知漏洞 total=0；未安装或更新依赖 | [npm-audit-result.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/npm-audit-result.json) |

原审计探针保留于 `artifacts/tech-debt-audit/20261128/`，它们对缺陷作正向断言，exit 0 表示**缺陷重现**；F27–F35 修复后不再满足对应缺陷断言。现行回归使用新增的 `animation-core-time-dependencies.test.mjs`、`toon-recording-lifetime.test.mjs`、`pipeline-warmup-lifetime.test.mjs` 、`gui-lifetime-hover.test.mjs` 及上面的原生像素／交互入口。QR 原探针与其旧编译字节继续作为缺陷证据保留；现行初值回归使用 `qr-initialization.test.mjs`，不会把旧探针的成功复现当作新实现失败。编译和诊断输出仅进入 artifacts。

GUI／core 主要探针直接转译当前 TS；HYA 的产品模块同样来自当前工作区，第三方依赖由已有验证 checkout 提供，两组独立装载清单均保留。QR 使用新转译的当前 P3 入口及本机现有 Engine package。源码身份、最终未改动检查及证据清单见 [completion.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/completion.json)。

原审计的 WGSL 编译运行于 Chrome 158.0.8127.37／NVIDIA Pascal 非 fallback adapter；只编译五段小 shader，无绘制或性能采样。编译消息已在 interact 内保存，但 runner 最后的 Win32_Process 清理检查遭 CIM 权限拒绝，退出 1；[原失败](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261128/core/float-literal-native-runner-failure.json)完整保留，不将其写成完整 WebGPU 门禁通过。GLSL 为源码级同类缺陷，未验证真实 WebGL 编译。

## 现有测试为何没有覆盖这些路径

- 数字框测试验证提交／步进／IME 和未聚焦 dispose，没有实际聚焦后关闭；新缺陷不是要求应用回调故意抛错。
- Popover 既有测试主要使用 manual trigger；自动 trigger 构造后的校验失败尚未覆盖。
- Carousel 测试覆盖 setIndex 与可见性，没有把指针路由到子控件后推进 autoplay 时钟。
- HYA 普通 runtime 已测试这些动画，但生产缓存测试使用能被当前启发式识别的 `.morph` 字段，未覆盖没有其他轨道的 legacy／node effects／composite。
- 现有材质及字体生命周期修复不能自动覆盖另一 renderer 或 BaseRenderer 的异步管线缓存；应按同一生命周期合同增加消费方对照，不重复发明资源 owner。

## 看似复杂但合理，应保留

- **可选 GUI 分包及公开入口边界。** Date／Upload／QRCode／Assistive 等复用共享底座；显式 QR canvas factory 和宿主 upload port 保留平台选择，不应为去重而引入全局 DOM 依赖。
- **GUI List 的呈现与 bind 分离。** 选择／展开只更新呈现，不重绑活跃编辑器，避免取消 IME 或覆盖草稿；不是两套行状态。
- **display 与 visible 两项状态。** 前者移出布局，后者停止交互／活动；不能仅为减少字段而合并。
- **AbortSignal 加请求身份双检查。** 生产者可以忽略 abort，因此 latest-wins 校验仍必要。
- **HYA 不可变几何快照及精确可变数组比较。** 它们隔离旧录制并兼容公开可变数据，不能通过借用可变数组来修复时间依赖问题。
- **静态早退、绘制顺序、未提交资源隔离及有界虚拟列表。** 本轮问题需要补齐失效条件与 owner 使用，不能以删除这些机制换取表面简化。大文件与高 churn 只是审查入口，未单独列为技术债。

## 快速修复清单与待明确语义

- [x] F33：共享科学记数法格式化规则，补各后端数字边界与编译反例。
- [x] F34：异常清理逐项执行，聚合原始与清理错误。
- [x] F35：QR 初值同步校验／显式初始化错误归属，保留合法生成与失效取消。
- [x] F27：关闭数字框不触发内部 disposed 错误，同时保留正常 blur 提交。
- [x] F29：自动 trigger 的参数先验证，构造失败后立即可重用借用 content。
- [x] F28：用实际命中＋原时钟补 popup／carousel 子树 hover 对照。

现行内部语义：数字框 owner 销毁时取消未提交草稿，正常失焦提交；复合 hover 包含显式关联弹层，即使共享 modal host 使其独立挂载。F32 继续沿用既有的实例累计诊断口径。

## 已解决项索引

以下是 F01–F26 的历史索引，F27–F32 的现行修复见前文；不表示本次重新跑过历史完整发布资格。原触发、修复、失败记录及完整验收数字均见[历史原文 ZIP](D:/HaiyueStudio/Engine/review/archive/tech-debt-audit-through-20261126.zip)，原文字节 SHA-256 为 `1ec93c555f7b2f513646f267cd8e048344bcfd924863b18a32869b2ff4f3c0cb`。

| ID | 状态 | 现行结论 |
| --- | --- | --- |
| F01 | RESOLVED | Mesh3D 材质纹理按请求代次及 disposed 状态释放迟到 handle。 |
| F02 | RESOLVED | HYA mask／effect 共用提交／取消／队列退休规则。 |
| F03 | RESOLVED | ECS 索引按 token×entity 匹配引用计数。 |
| F04 | RESOLVED | typed journal 按 owner×component 合并，保留多消费者游标。 |
| F05 | RESOLVED | composite 格式校验改显式栈，深链保留错误合同。 |
| F06 | RESOLVED | 滚动布局在最终内容坐标下只遍历孩子一次。 |
| F07 | RESOLVED | 布局默认测量复用本次 arrange 索引。 |
| F08 | RESOLVED | GUI 文本命中、光标及选区共用前缀度量。 |
| F09 | RESOLVED | HYA 文本按实际像素输入失效，离散内容不逐帧重画。 |
| F10 | RESOLVED | 缺省 morph slot 共享不可变零缓冲。 |
| F11 | RESOLVED | 主题状态与资源变化分离，增量维护 paint spans。 |
| F12 | RESOLVED | 移除未用压缩依赖链，Basis 字节带来源、许可和哈希；serialize 兼容修补。 |
| F13 | RESOLVED | 音频 slot 分开管理 committed lease 和候选替换。 |
| F14 | RESOLVED | 文档如实说明 Pages 来源与 npm／签名标签相互独立。 |
| F15 | RESOLVED | PBR 槽请求代次处理 A→B→A 乱序。 |
| F16 | RESOLVED | 变换缓存包含父身份，支持同 revision 换父。 |
| F17 | RESOLVED | Bitmap atlas 异步请求受 renderer／字体代次约束。 |
| F18 | RESOLVED | 共享 BitmapText 各消费者独立读取几何变化。 |
| F19 | RESOLVED | Tabs／Collapse 逐项清理后聚合外部观察者异常。 |
| F20 | RESOLVED | Tab 构造先验证派生 ID，取得租约立即登记回滚。 |
| F21 | RESOLVED | 固定标签跳过无用字体／皮肤查询。 |
| F22 | RESOLVED | HYA 转换／分配前检查原有聚合预算。 |
| F23 | RESOLVED | core 按 owner 复用不可变几何快照，保留旧帧隔离。 |
| F24 | RESOLVED | 语义按父先子后传播 hidden，保留导航／阅读顺序。 |
| F25 | RESOLVED | Material Graph 单次结构扫描来源与行列。 |
| F26 | RESOLVED | 图遍历／lowering／IR 可达性改显式栈，CSE 来源增量去重。 |

## 覆盖限制

这是基于历史、静态边界和定向行为复现的审计，不是逐行完备验证或发布批准。后续修复针对 F27–F35。Spine、Animation3D、音频、VN、解析器和发布脚本仅作抽查，不能据此宣称其没有其他问题。未测试 Mac／iPhone，未重建性能基线，未改变旧失败或预算。当前工作区原有修改保留，未 commit、push 或发布。
