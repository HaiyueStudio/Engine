# Engine 技术债复审

日期：2026-11-28。范围为 `D:/HaiyueStudio/Engine` 当前工作区，HEAD `a8b7ae6` 加现有未提交修改，包含 GUI P0–P3 与此前修复。按 [tech-debt-audit](C:/Users/Administrator/.codex/skills/tech-debt-audit/SKILL.md) 执行，只修改本报告与归档索引，产品、测试、依赖、API、基线和预算保持。

## 执行摘要

- 确认 **7 项 NEW（F36–F42，均为 Medium）**，以及 **F33 的 specialization 残留（PARTIAL）**。F01–F32、F34–F35 继续为 RESOLVED。未确认新的 Critical／High；不代表未审路径没有问题。
- 优先处理失败准入和同步发布：Spine 丢失临时纹理，Animation3D 失败 action 污染 binding，QR／Notification 在正常 invalidation 回调销毁时失去候选资源归属。
- Engine／Scene／World／SceneFlow 的卸载异常会跳过其他独立 owner，并留下无法重试的半销毁状态。按同一生命周期问题计一项，不按类数重复计数。
- F33 前次修复覆盖了 Typed IR 两后端，遗漏第三个 specialization formatter。同一合法 `1e21`，普通 literal 已通过，specialization 默认值／override 仍生成非法 WGSL。前次通过记录保留，不能据此关闭这个入口。
- 数值合同还有独立缺口：合法 i32 最小值生成不可编译表达式；越界 i32／u32／f32 反而通过 IR 校验。另有状态机 v2 在限额检查前完整复制输入的可避免开销。
- 2,350 份输入与刚完成的验证逐文件 SHA-256 一致，引用原 **3,010 项测试、类型／构建、25 节点 Shader Stage 14** 通过记录；本轮另做独立探针复核、15 组原生 WGSL 编译及现有 26 项 GUI 回归。通过的旧测试没有覆盖本轮失败窗口。
- 新跑工作区／601 模块／API 检查通过，npm 官方只读 audit 为 **0 项已知漏洞**。本轮没有常态 FPS 或峰值内存实测，不把结构计数写成性能提升，也不调整预算。
- [复审前完整原文](review/archive/tech-debt-audit-through-f35-20261128.zip)已压缩并逐字节回读验证，保留原路径及 [SHA-256 清单](review/archive/tech-debt-audit-through-f35-20261128.json)。活动报告只保留问题、方法、结论和证据。

## 架构模型与审查入口

Engine 拥有场景／ECS、输入、资源和 WebGPU 帧生命周期；Extensions 通过公开入口组合可选 GUI、动画、音频、剧情和源格式适配。Animation-spec 独立负责格式校验和离线转换，Shader Language 在构建期把 frontend 降到同一 Typed IR，再生成代码与 reflection。脚本组织验证，不应成为第二套运行时。

本轮问题集中在既有合同的边界：候选资源交付前后的归属、同步通知引起的重入、失败后引用回滚，以及数值／结构限额的准入时机。缓存、快照和不同 owner 的存在本身不是重复代码。按读取的 README、manifest、仓库地图与 ADR 未发现需要推翻这套分层的证据。

重新获取最近 200 条提交及六个月 churn；排除 generated、vendor、dist 等后，源码／工具／示例共 **2,236 文件、303,501 行**，四个基础 workspace 的 src 共 **1,244 文件、189,188 行**。这不是热路径成本。最大文件与高 churn 的交集仍为 Animation2DRuntime、Animation2DRenderSystem、GuiSystem；前 20 大文件、前 20 高 churn 文件和原始源码哈希见 [orientation.json](artifacts/tech-debt-audit/20261128/re-audit-02/orientation.json)。

## 发现

以下是已确认行为缺陷或准入开销；S／M 表示修改和验证跨度，不是工时承诺。

| ID／状态 | 类别 | File:Line | 严重度 | 工作量 | 问题、触发与影响 | 具体建议 |
| --- | --- | --- | --- | --- | --- | --- |
| **F33 PARTIAL** | 数值格式化残留 | [specialization.ts:77](D:/HaiyueStudio/Engine/shader-language/src/specialization.ts:77)、[生成入口:65](D:/HaiyueStudio/Engine/shader-language/src/specialization.ts:65) | Medium | S | 新 floatLiteral helper 未被 specialization 使用。合法 f32 `1e21` 的默认值与 override 仍生成 `1e+21.0`，Composer 成功返回，原生编译拒绝；`1e20` specialization 和 `1e21` 普通 literal 对照均成功。 | 复用已存在的浮点 formatter，保留该入口原有后缀与 variant/hash 语义；补公开 Composer 的默认值／override 原生编译。不要撤销已正确的两后端修复。 |
| **F36 NEW** | Spine 临时资源回滚 | [Spine2DGpuRenderer.ts:135](D:/HaiyueStudio/Engine/extensions/src/spine/Spine2DGpuRenderer.ts:135)、[取得纹理:146](D:/HaiyueStudio/Engine/extensions/src/spine/Spine2DGpuRenderer.ts:146)、[Spine2DRuntime.ts:436](D:/HaiyueStudio/Engine/extensions/src/spine/Spine2DRuntime.ts:436) | Medium | M | 第一 atlas 页取得纹理后，后页图片失败；或最后图片完成时取消，均在 pages 交给 runtime 前抛错。共享审计 GPU 中 renderer.destroy 后 created=2／destroyed=1／live=1，成功交付／销毁对照归零。 | pages／buffers 成功交付前由局部 owner 持有，失败或取消逐项释放；图片加载传递取消信号，await 返回后验证代次。保持成功路径的所有权转移。 |
| **F37 NEW** | Animation3D 准入事务 | [Mixer.ts:90](D:/HaiyueStudio/Engine/extensions/src/animation3d/runtime/mixer/Mixer.ts:90)、[冲突:298](D:/HaiyueStudio/Engine/extensions/src/animation3d/runtime/mixer/Mixer.ts:298) | Medium | S | createAction 逐 track retain，后项合同冲突时不回滚前项。8 次失败使 binding 从 1 增至 9；移除全部正常 action 后仍余 8 个，并拒绝随后本应合法的新合同。 | 全部预检后再提交，或记录每次成功 retain 并在失败时逆序 release；既有共享 binding 的引用数也必须恢复，不能清空整个 mixer。 |
| **F38 NEW** | GUI 发布重入 | [QRCode.ts:17](D:/HaiyueStudio/Engine/extensions/src/gui-assets/QRCode.ts:17)、[Notification:23](D:/HaiyueStudio/Engine/extensions/src/gui-overlays/notification.ts:23)、[登记:24](D:/HaiyueStudio/Engine/extensions/src/gui-overlays/notification.ts:24) | Medium | M | image.setSource／element.add 会同步通知公开 root invalidation。回调正常 dispose 时，候选 lease／alert 尚未进入 owner；返回后代码仍向 dead owner 提交。QR 返回 true，重复 dispose／root.destroy 后 lease 释放 0 次；Notification 留下 entry 和无法再次借用的 action frame。 | 通知前建立受控候选归属与 rollback，通知后重查 dead、signal 和条目身份，再提交；同时保留旧 committed lease，防止仅提前赋值造成另一处泄漏。两处复用规则，不新增公共组件框架。 |
| **F39 NEW** | 场景与核心终态清理 | [Scene.ts:136](D:/HaiyueStudio/Engine/engine/src/scene/Scene.ts:136)、[Engine.ts:395](D:/HaiyueStudio/Engine/engine/src/core/Engine.ts:395)、[World.ts:340](D:/HaiyueStudio/Engine/engine/src/ecs/World.ts:340)、[SceneFlow.ts:125](D:/HaiyueStudio/Engine/extensions/src/scene-flow/SceneFlow.ts:125) | Medium | M | 一个卸载 hook／System.destroy 抛错会跳过其他插件、实体、资产和终态。Scene 留在 destroying；Engine／World 已标 destroyed 却仍保留引用；Flow 已 disposed 但第二个 retained Scene 未释放。重试均早退。正常 hooks 对照全部释放。 | 保留先失效的重入保护，独立项逐个清理，finally 完成解绑／终态，最后聚合错误。必须覆盖 [PluginHost.clear:181](D:/HaiyueStudio/Engine/engine/src/core/EnginePluginHost.ts:181) 和内部 World 循环；只包装最外层不足，且要保持 shared System／借用 target 的所有权。 |
| **F40 NEW** | Typed IR 数值合同 | [rules.ts:177](D:/HaiyueStudio/Engine/shader-language/src/ir/rules.ts:177)、[WGSL i32 编码:313](D:/HaiyueStudio/Engine/shader-language/src/backend/wgsl.ts:313) | Medium | M | 一方面，合法 `-2147483648` 被写成 `-2147483648i`，原生编译报不可表示；邻值和两种等价安全表达式通过。另一方面，u32=2^32、i32 两端越界、f32=1e39 均被 IR 接受，原生编译全拒绝；公开 Material Graph 对 1e39 仍返回 ok。不是已修 F33 的浮点指数拼写问题。 | 明确并统一 32 位表示范围的准入规则；单独处理 WGSL i32 最小值的合法编码。保留合法负零／舍入策略，覆盖标量、向量、Graph／IR 入口及原生边界；不要通过拒绝合法 i32 下界规避编码问题。 |
| **F41 NEW** | Worker 协议身份 | [WorkerChannel.ts:112](D:/HaiyueStudio/Engine/engine/src/async/WorkerChannel.ts:112)、[消息合并:138](D:/HaiyueStudio/Engine/engine/src/async/WorkerChannel.ts:138)、[回包匹配:201](D:/HaiyueStudio/Engine/engine/src/async/WorkerChannel.ts:201) | Medium | S | 公开 experimental request 接受任意 Record；payload 在内部 version/id/type 后展开。`{id:99}` 发送 99，但 pending 保存 1；正确回包后仍 pending=1／fault=false。严格 TS 类型检查允许该调用。影响直用 channel 的调用者；现有重点包装器用 ownerId／嵌套 request 规避了它。 | 协议字段最后写入，或建立 pending 前明确拒绝保留键。补回包／取消／无残留对照；保留未知迟到回包的丢弃规则。 |
| **F42 NEW** | 解析准入与复制成本 | [state-machine-v2/parser.ts:30](D:/HaiyueStudio/Engine/animation-spec/src/state-machine-v2/parser.ts:30)、[clone:32](D:/HaiyueStudio/Engine/animation-spec/src/state-machine-v2/parser.ts:32)、[限额:39](D:/HaiyueStudio/Engine/animation-spec/src/state-machine-v2/parser.ts:39) | Medium | S–M | structuredClone 在结构、未知字段和数量限额检查前执行。maxChannels=1 的普通 JSON 仍先克隆 4,096 项才报 limit；未知字段中的 16 MiB TypedArray 也先复制才报格式错。限额未限制拒绝前的复制工作。 | 先只读检查结构与聚合预算，再复制已准入数据、完整验证并冻结；保留调用方不被冻结和输出快照隔离，保持错误 code/path 与原限额。证据仅计复制结构／字节，不宣称峰值内存或时延。 |

## 优先处理的五组变更

1. **F36：建立临时 atlas owner。** `pages` 取得一页就登记清理；`try` 中加载、验证取消并分配 runtime，成功交付时转移所有权，`finally` 清理未转移资源。增加后页失败、最后 await 后取消、成功销毁三组对照。
2. **F38：补齐同步发布事务。** QR 与 Notification 各自保存候选和旧 committed 对象；发布前可被 dispose 找到，发布后验证身份。测试 root invalidation 中的 dispose、新请求、以及发布失败，分别断言新旧租约恰好释放一次。
3. **F37：回滚 action retain。** 用局部成功列表包住 retain 循环；中途失败逆序退还，再原样抛错。对“新增 binding”“既有兼容 binding 引用增加”“修正合同后再次创建”分别验证。
4. **F33＋F40：统一数值规则和各出口。** specialization 接入现有 float formatter；类型准入检查表示范围；WGSL 对合法 i32 最小值使用可编译表达。原生验证 default／override、上下界、邻值及非法值，不能只查字符串。
5. **F39：按现有 owner 逐层完成清理。** PluginHost／World 内部循环也隔离每个错误，Scene／Engine／Flow 无论子项失败都完成引用解绑，最后汇总。保留提前失效、共享 System 引用及借用 render target 合同。F42 随解析器批次做前置预算，F41 可独立小修。

## 快速项

- [ ] F33：specialization 复用已有 formatter，补公开默认值／override 原生编译。
- [ ] F37：成功 retain 的逆向回滚及合法重试对照。
- [ ] F41：发送身份字段不可被 payload 覆盖，补直接消费者类型／行为对照。

## 证据与现有测试缺口

这些探针以缺陷作正向断言，**exit 0 表示复现，不表示已修复**。主审独立复核到同样结果；动画复核改用当前 Engine 目录的第三方依赖，未加载旧 checkout 的产品代码。

| 范围 | 证据 | 原测试缺口 |
| --- | --- | --- |
| F33／F40 | [15 组原生编译](artifacts/tech-debt-audit/20261128/re-audit-02/shader-boundaries-v2.json)／[入口](artifacts/tech-debt-audit/20261128/re-audit-02/shader-boundaries-v2.mjs)；合法边界、独立等价语法和 F33 已修 literal 均有对照 | [numeric-literals.test.mjs:5](D:/HaiyueStudio/Engine/shader-language/test/numeric-literals.test.mjs:5) 只覆盖两个后端的浮点 literal；[composer.test.mjs:235](D:/HaiyueStudio/Engine/shader-language/test/composer.test.mjs:235) 的 specialization 用例主要是 bool，未覆盖大浮点默认值／override 和 i32 最小值。 |
| F36 | [atlas rollback](artifacts/tech-debt-audit/20261128/re-audit-02/recheck-animation/spine-atlas-rollback.json) | 既有 parser／plugin 生命周期检查没有分页取得纹理后的失败或取消。使用共享审计 GPU，未测真实 Spine 像素／GPU 泄漏字节。 |
| F37 | [mixer admission](artifacts/tech-debt-audit/20261128/re-audit-02/recheck-animation/mixer-admission.json) | [animation3d-public-facade.test.mjs:120](D:/HaiyueStudio/Engine/extensions/test/animation3d-public-facade.test.mjs:120) 覆盖非法 track 与重复 action ID，未断言 retain 中途失败后的 owner 状态。 |
| F38 | [QR](artifacts/tech-debt-audit/20261128/re-audit-02/recheck-gui/qr-publication.json)、[Notification](artifacts/tech-debt-audit/20261128/re-audit-02/recheck-gui/notification-publication.json) | [qr-initialization.test.mjs:15](D:/HaiyueStudio/Engine/extensions/test/qr-initialization.test.mjs:15) 覆盖 await 期间取消；[gui-p1.test.mjs:49](D:/HaiyueStudio/Engine/extensions/test/gui-p1.test.mjs:49) 在 open 已登记后清理，未穿过同步发布窗口。当前相关 26 项回归仍通过。 |
| F39 | [Scene](artifacts/tech-debt-audit/20261128/re-audit-02/recheck-core/scene-destroy-failure.json)、[Engine／World](artifacts/tech-debt-audit/20261128/re-audit-02/recheck-core/owner-teardown-failure.json)、[Flow](artifacts/tech-debt-audit/20261128/re-audit-02/recheck-core/scene-flow-teardown-failure.json) | 既有 scene／lifecycle／scene-flow 测试覆盖正常重复销毁与安装回滚，没有卸载／System 清理抛错后的其余 owner。CPU 状态与引用证据，不换算 GPU 字节。 |
| F41 | [协议对照](artifacts/tech-debt-audit/20261128/re-audit-02/recheck-core/worker-admission.json)、[公开 TS 类型证明](artifacts/tech-debt-audit/20261128/re-audit-02/recheck-core/worker-public-type-proof.json) | 已有测试检查 queue、latest、取消与非法回包，没有发送 payload 污染内部身份。探针记录正确回包后一轮事件循环仍 pending，无需等待超时。 |
| F42 | [准入与 clone](artifacts/tech-debt-audit/20261128/re-audit-02/recheck-animation/state-machine-admission.json) | [state-machine-v2-parity-contract.test.mjs:19](D:/HaiyueStudio/Engine/extensions/test/state-machine-v2-parity-contract.test.mjs:19) 检查最终错误与限额，没有计拒绝前的复制。普通 JSON 与 getter 辅助计数分别复现，排除只因 getter 的解释。 |

[源码与探针复核清单](artifacts/tech-debt-audit/20261128/re-audit-02/completion.json)保存最终范围、SHA-256、命令、成功对照和限制。首个编译探针把合法 i32 下界当必过对照，其意外失败促成 F40；保留原记录，后续另用合法等价语法确认编码问题。诊断 loader 的一次解析递归属于夹具问题，修正后用当前依赖重跑，不计产品缺陷。

## 审查维度与验证口径

| 维度 | 本轮结论 |
| --- | --- |
| 架构／一致性 | 工作区、601 模块、API 检查通过；主要问题是已存在 owner 规则没有贯穿失败／发布窗口。没有依据按文件大小拆分运行时。 |
| 类型／合同 | F33、F40、F41；没有把泛型、unknown 或私有类型断言的数量直接当作缺陷。 |
| 测试 | 以 [同源复核](artifacts/tech-debt-audit/20261128/re-audit-02/reused-validation.json)引用原 3,010 项完整测试、类型、构建及 25 节点 Shader 验证；另跑新探针及相关 26 项回归。未生成覆盖率百分比。 |
| 依赖／配置 | [新 npm 官方 audit](artifacts/tech-debt-audit/20261128/re-audit-02/npm-audit-receipt.json) 为 0 漏洞，锁文件身份已记录；未安装工具或更新依赖。未确认新的重复依赖或配置缺陷。 |
| 性能／资源 | F36–F39 的资源／引用状态、F42 的准入前复制有计数；没有新常态 FPS、正式压力或峰值堆内存结论。 |
| 错误与观测 | F39 的终态不能代表清理完成，F41 pending 却无 fault；应保留原始与清理错误和真实计数。 |
| 安全卫生 | 数据准入问题见 F40／F42；检查了发布终端与日志脱敏边界，未确认新的凭据问题。没有做全面攻防、模糊测试或秘密扫描。 |
| 文档 | 历史验收记录按原身份保留；当前状态从证据更新。本轮未确认需要单列的高影响文档缺陷。 |

## 看似复杂但合理，应保留

- [List 的呈现与 bind 分离](D:/HaiyueStudio/Engine/extensions/src/gui-collections/List.ts:109)、布局 display 与交互 visible 分工、独立的 GPU 录制快照都保护 IME、虚拟回收和旧帧，不是重复状态。
- [LatestRequest 的 abort 加身份检查](D:/HaiyueStudio/Engine/extensions/src/gui-common/latest.ts:6)仍必要；F38 要补同步通知后的检查窗口，不能删除 latest-wins 或把所有通知改成异步。
- [Upload 的首次 await](D:/HaiyueStudio/Engine/extensions/src/gui-assets/Upload.ts:30)建立 draining lease 后再接触可重入 host；不应仅为少一次微任务删除。
- [RenderView 只释放自有区域](D:/HaiyueStudio/Engine/engine/src/core/RenderView.ts:104)，不销毁借用 target；F39 的清理不能扩大所有权。
- [WorkerChannel 丢弃未知 id](D:/HaiyueStudio/Engine/engine/src/async/WorkerChannel.ts:201)保护取消后的迟到响应。F41 修发送身份，不能放松接收校验。
- [legacy glTF CUBICSPLINE 仅取 value](docs/engine-guide/gltf-models-and-animation.md#L347)已有兼容说明；完整 Animation3D adapter 是另一已声明能力，不能不经迁移直接替换旧语义。
- 状态机的输出冻结与调用方对象隔离有正对照；F42 调整准入顺序，保留快照。Typed IR 的 f32 舍入、资源布局与代码生成边界也保持。

## 待维护者明确的语义

- **Worker 满额时背压与 latest-wins 的优先级。** maxPending=1 时当前实现先拒绝新请求，保留旧请求；容量 2 才正常替换。已复现，但未找到明确优先级合同，重点 ray client 又主动先 abort 旧 owner，因此只列开放问题，不计 F41 的第二个缺陷。
- README 顶部仍导向 0.2.1 候选，而现行 package／release manifest 已有后续版本。是否保留为历史链接或改为常青发布索引需按文档用途确定，本轮不把历史版本号直接当错误。

## 已解决记录与限制

| 范围 | 现行状态 | 原始依据 |
| --- | --- | --- |
| F01–F26 | RESOLVED | [历史原文及清单](review/archive/tech-debt-audit-through-20261126.json) |
| F27–F29 | RESOLVED | [20 项新增回归、16 项浏览器交互及完整验证](artifacts/tech-debt-audit/20261128/f27-f29/completion.json) |
| F30–F32 | RESOLVED | [20 项新增回归、50 项原生像素对照及完整验证](artifacts/tech-debt-audit/20261128/f30-f32/completion.json) |
| F33 | PARTIAL | 两个 Typed IR 后端已修；specialization 残留见本报告。前次 [31 项新增回归与验证](artifacts/tech-debt-audit/20261128/f33-f35/completion.json)不覆盖该入口。 |
| F34–F35 | RESOLVED | [异常清理／QR 初值回归及完整验证](artifacts/tech-debt-audit/20261128/f33-f35/completion.json)；F38 是发布重入，F39 是其他 owner，不重报它们已修的触发路径。 |

这是基于结构、历史和定向反例的复审，不是逐行完备验证或发布批准。主审独立复核并收敛了三个只读子审结果；没有修复本轮候选、重采正式性能、晋级基线或测试 Mac／iPhone。当前源代码和已有修复保持原字节，旧报告、原失败和本轮诊断均保留；未 commit、push 或发布。
