# API and release scope

- [Engine release manifest](release-manifest.json): four local npm libraries and the Engine example catalog.
- [Scope validator](verify-release-scope.mjs): Engine-owned metadata validation.
- [Historical Studio manifest](studio-release-manifest.json): preserved pre-split record; not consumed by Engine library release gates.
- [Ownership decision](../../docs/for-ai/adr/0105-independent-library-release-gates.md).
- [0.2.0 capability evidence](0.2.0-capability-evidence.json) and [diagnostic attribution runner](measure-0.2.0-capabilities.mjs).
- [I18n API review and validation](i18n-validation.md).
- [Narrative API review and validation](narrative-validation.md).
- [loaders.gl dependency range review](loaders-gl-dependency-review.md).
- [Extensions capability, ownership and package review](extensions-capability-review.md).
- [Animation text OpenType loading review](animation-opentype-loading-review.md).
- [Share content API review and validation](share-content-validation.md).

