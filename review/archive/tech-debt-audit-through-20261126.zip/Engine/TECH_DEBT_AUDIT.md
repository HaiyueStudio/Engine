# Engine 技术债审计

复审日期：2026-11-26。按本机 [tech-debt-audit](C:/Users/Administrator/.codex/skills/tech-debt-audit/SKILL.md) 重复审计模式执行。主审为 **D:/HaiyueStudio/Engine 当前工作区**（HEAD a8b7ae6 加已有修改），不是仅审旧发布构建；随后按用户指示完成 F15–F26 修复；32 份具名文件已同步，其他原有源码改动保持。

## 执行摘要

- **F01–F26 均为 RESOLVED**；本轮完成 F15–F26 十二项修复，没有新增公开 API、依赖或预算调整。
- PBR 与 Bitmap atlas 按请求代次和资源归属释放；共享 BitmapText 的每个消费者独立读取变化，待提交与取消的绘制仍保留资源。
- 同版本换父会重算变换；GUI 异常清理会释放所有借用租约；隐藏语义按父先子后求值。
- HYA 在预算检查后分配，稀疏颜色变化复用不可变几何；固定标签跳过无用字体查询。
- Material Graph 一次定位结构化来源，遍历／lowering／IR 可达性使用显式栈；8,192 节点深链／深环和原 WGSL／反射／canonical golden 均通过。
- F15–F26 新增 **61／61**、相关 **213／213** 通过；修复空目录清单后，全量 **2865／2865** 通过（四个 workspace 2857 项，示例 8 项），0 失败／0 跳过。主工作区的新增优化回归及本次 10 项合同检查也通过。
- 原四包预算、API／边界／严格类型／架构、着色器检查及 Stage 14 的 **25／25** DAG 节点通过。真实 WebGPU **36 项**通过（最大通道差 0），GUI cache 另有 16 帧通过，GPU 验证错误和资源残留均为 0。
- 原有空 cubism 目录清单失败已修复；冻结合同、全部运行时文件及预算不变，原失败记录保留。此次没有提交、推送或发布，也未生成正式性能基线。

## cubism 空目录清单修复（2026-11-26）

问题是旧检查把文件系统目录直接当作模块：冻结清单同时含有历史空目录 `cubism` 和仍存在的 `cubism.ts` 入口，Git 不保存前者，干净 checkout 因而误报。

[模块清点辅助检查](D:/HaiyueStudio/Engine/extensions/test/helpers/hya-foundation-module-census.mjs:1) 显式把历史别名绑定到真实 `cubism.ts`，校验两项能力归属完全相同，并精确覆盖所有有文件内容的模块。没有改冻结清单、补空目录或跳过原合同测试。新增四项回归覆盖有／无空目录、新增未分类源码、删除已分类实现，以及缺失入口／归属不一致；原已分类目录恢复源码仍可通过。

主工作区及无空目录的隔离副本各 **10／10** 定向检查通过；全仓 typecheck、test、build、workspace 边界和 API 检查通过，全量 **2865／2865**，零失败／零跳过。上一轮 32 份优化文件及全部预算哈希保持，冻结 `hya-022-contract.json` SHA-256 仍为 `8d46c0cf3b6a388c861c7ca34ccbab4b71913cb0ab100669394d5ec5465f37c5`。完整凭据见 [validation-result.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261126/cubism-census/validation-result.json)。以下历史批次的失败数量保留其当时口径。

## F15–F26 修复记录（2026-11-26）

| ID | 状态 | 问题、方法与结论 |
| --- | --- | --- |
| F15 | RESOLVED | [PbrMaterialResources.ts:213](D:/HaiyueStudio/Engine/engine/src/renderer/PbrMaterialResources.ts:213) 每纹理槽记录请求代次，A→B→A 的旧 handle 即使来源相同也释放；继续使用原 AssetManager／RecordedGpuResources。 |
| F16 | RESOLVED | [Transform2D.ts:129](D:/HaiyueStudio/Engine/engine/src/components/Transform2D.ts:129) 和 [Transform3D.ts:101](D:/HaiyueStudio/Engine/engine/src/components/Transform3D.ts:101) 缓存父矩阵身份与 revision；同版本换父、根与子树换挂及空间索引回归通过，静态早退保留。 |
| F17 | RESOLVED | [BitmapTextRenderer.ts:481](D:/HaiyueStudio/Engine/engine/src/renderer/BitmapTextRenderer.ts:481) 字体请求可取消且受 renderer epoch／font generation 约束；迟到 handle 释放，自有 bitmap 关闭，借用图片仍归调用者。相机、模型、参数和 atlas 统一遵循原录制／submit／cancel／fence 生命周期。 |
| F18 | RESOLVED | [BitmapTextRenderer.ts:619](D:/HaiyueStudio/Engine/engine/src/renderer/BitmapTextRenderer.ts:619) 每实体缓存已消费文字、字体与实际使用的 glyph／kerning；共享组件不会吞掉其他消费者的变化，静态、空文字和纯颜色修改不重建几何。 |
| F19 | RESOLVED | [panel-cleanup.ts](D:/HaiyueStudio/Engine/extensions/src/gui-layout/panel-cleanup.ts:1) 共用异常聚合；Collapse／Tabs 提前失效防重入，所有 detach／off／release 独立完成后才报告观察者错误。外部 focus observer 持续抛错仍会报告，不能强行更改其归属。 |
| F20 | RESOLVED | [tab-container.ts:35](D:/HaiyueStudio/Engine/extensions/src/gui-layout/tab-container.ts:35) 先捕获并验证全部派生 ID，再获取租约；取得即登记，后续构造／挂载失败也释放当前项，非法 UTF-16 返回原 LayoutError 类别。 |
| F21 | RESOLVED | [GuiSystem.ts:968](D:/HaiyueStudio/Engine/engine/src/gui/systems/GuiSystem.ts:968) 仅未受布局管理的 autoWidth 标签解析字体／样式；固定标签跳过无用读取，HelpDialog 与实时字体行为保留。 |
| F22 | RESOLVED | [validation.ts](D:/HaiyueStudio/Engine/animation-spec/src/validation.ts:1) 和 [binary.ts](D:/HaiyueStudio/Engine/animation-spec/src/binary.ts:1) 在转换／分配前消费路径、morph、track 的原有预算，辅助长度先校验；JSON 与 compact binary 共用边界，copyFloatData=false 和旧错误优先序保留。 |
| F23 | RESOLVED | [CoreGeometrySnapshotCache.ts](D:/HaiyueStudio/Engine/extensions/src/animation/production/CoreGeometrySnapshotCache.ts:1) 每 core 有界复用不可变位置／索引／UV 快照，精确检查公开可变数组及 topology；颜色变化零新增几何复制，真实 morph、旧待提交帧与回滚互不污染，dispose 清空缓存。仍使用原 draw owner 和渲染器。 |
| F24 | RESOLVED | [SemanticsRuntime.ts:40](D:/HaiyueStudio/Engine/extensions/src/animation/interaction/SemanticsRuntime.ts:40) 一次构建父先子后求值序，先传播祖先 hidden；保留原 reading／navigation 输出排序，隐藏子项动作被拒绝，恢复、checkpoint 与 announcement 回归通过。 |
| F25 | RESOLVED | [sourceLocations.ts](D:/HaiyueStudio/Engine/shader-language/src/graph/sourceLocations.ts:1) 单次结构扫描节点来源和行列；metadata 同名 ID、字符串伪节点、转义键、CRLF 和重复属性均按实际 JSON 结构处理，消除逐节点前缀扫描。 |
| F26 | RESOLVED | [materialCompiler.ts:209](D:/HaiyueStudio/Engine/shader-language/src/graph/materialCompiler.ts:209)、[canonical.ts](D:/HaiyueStudio/Engine/shader-language/src/ir/canonical.ts:1) 与 [optimizer.ts](D:/HaiyueStudio/Engine/shader-language/src/ir/optimizer.ts:1) 使用显式工作栈和索引；CSE 来源去重也改为增量集合，最终一次冻结。没有新增拒绝合法图的深度／节点限制，原 cycle／reference 诊断和输出字节保持。 |

完整验收与逐文件 SHA-256 见 [validation-result.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261126/f15-f26/validation-result.json)。隔离副本承载完整门禁，32 份修复字节与主工作区一致；主工作区与发布基底的 42 份其他差异均原样保留，并另做主工作区类型检查、构建及新增回归。2,125 份原输入中，范围外哈希无意外变化。

四个原预算 tarball／消费者门禁全部通过，详情见 [package-result.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261126/f15-f26/package-result.json)。真实 GPU 覆盖 1×／4×MSAA、共享 BitmapText、未提交的旧／新批次、销毁前录制、HYA 缓存／非缓存、可变几何和旧快照；原始 [native-result.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261126/f15-f26/native-result.json) 与全部失败日志保留。此为修复验证，不替代正式性能资格或发布资格。

## 当前架构模型与审计基线

Engine 持有 Scene／ECS、输入域和 GPU 提交／资源归属；Extensions 通过公开入口装配布局／集合、HYA、音频和视觉小说。animation-spec 负责来源无关格式及输入边界，shader-language 在构建期将图与 DSL 降为 Typed IR。真正值得统一的是请求身份、消费者 revision、资源租约和遍历索引；不能因实现都处理文字／节点，就合并成第二套通用运行时。

本轮重新读取 README、manifest、仓库地图、API 边界、各 AGENTS，保存 200 条提交和六个月 churn。统计排除生成物／已构建 bundle 后的 2,118 份源码及工具文件、299,916 行；**并非纯运行时 LOC，也不与首轮不同筛选口径直接比较**。前 20 大文件、前 20 高变更文件及交集见 [orientation.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261126/repeat/orientation.json)。大文件仅用于定位审查，不是缺陷或拆分依据。

主要复现直接转译当前主工作区 TS。GUI 借用既有构建前校验五份相关源码相同；编译器校验全部 shader-language/src 字节相同。HYA 动态装载了 645 份当前源码，15 份与验证目录的背景差异完整保留，未替换成那些旧产物。核对范围、逐文件哈希和来源均在原始结果中。

## 修复前问题与实施依据（F15–F26，现均已修复）

| ID | 状态 | 类别 | File:Line | 严重度 | 工作量 | 问题、触发与影响 | 具体建议 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| F15 | RESOLVED | PBR／资产生命周期 | [PbrMaterialResources.ts](D:/HaiyueStudio/Engine/engine/src/renderer/PbrMaterialResources.ts:229) | Medium | M | A→B→A 发生在首个 A 尚未完成时，同源相等判断放行两个独立 handle；后者覆盖材质槽。实证 A refs=2，材质淘汰后仍为 1，直到整个 renderer 销毁才归零。 | 每槽请求代次识别最新请求，过时 handle 立即释放；保持 RecordedGpuResources 的提交后退休。 |
| F16 | RESOLVED | 变换缓存／正确性 | [TransformStore.ts](D:/HaiyueStudio/Engine/engine/src/frame/TransformStore.ts:168)、[Transform3D.ts](D:/HaiyueStudio/Engine/engine/src/components/Transform3D.ts:102) | Medium | M | 同 World 换父时，两个父组件恰有相同 worldVersion，子矩阵错误命中缓存。父位置 10／20、局部位置 1，换父后仍为 11，预期 21；手动 markDirty 才恢复。 | 将父身份与 revision 一起纳入缓存，或由 hierarchy 代次强制重算；同时覆盖 2D／3D、子树及空间索引。 |
| F17 | RESOLVED | 字体图集／异步生命周期 | [BitmapTextRenderer.ts](D:/HaiyueStudio/Engine/engine/src/renderer/BitmapTextRenderer.ts:412) | Medium | M | 字体 fetch／位图等待中淘汰字体或销毁 renderer，迟到回调仍创建纹理并标 loaded。共享审计设备中，缓存淘汰后 live 1→2，renderer 销毁后 live 0→1；自建 ImageBitmap close=0。 | 记录字体 owner／请求代次并取消；失效时不创建纹理，finally 只关闭自建 bitmap，保留借用 pageImages。复用已有资产请求归属。 |
| F18 | RESOLVED | 文本失效／多消费者 | [BitmapTextRenderer.ts](D:/HaiyueStudio/Engine/engine/src/renderer/BitmapTextRenderer.ts:268)、[BitmapText.ts](D:/HaiyueStudio/Engine/engine/src/components/BitmapText.ts:55) | Medium | M | 共享 BitmapText 的 dirty 被第一个消费者清除。A→AA 后首实体为 12 顶点，第二实体及第二 renderer 仍为 6，后续静止帧不自愈。 | 每份缓存保存几何 revision／输入身份，继续复用 buildTextMesh；不能让一个 renderer 破坏性消费全局变更标记。 |
| F19 | RESOLVED | GUI dispose／异常安全 | [Collapse.ts](D:/HaiyueStudio/Engine/extensions/src/gui-controls/Collapse.ts:80)、[tab-container.ts](D:/HaiyueStudio/Engine/extensions/src/gui-layout/tab-container.ts:150) | Medium | M | dispose 先置 dead，再调用可抛错的焦点观察者。异常使摘树、解绑和 content frame 释放全部中断；重试又直接返回。实证借用内容一直被占有，无法用于新组件。 | 保留提前失效防重入，但分别执行全部独立清理，完成后统一抛聚合错误；释放不能依赖某个应用回调成功。 |
| F20 | RESOLVED | GUI 构造／租约回滚 | [tab-container.ts](D:/HaiyueStudio/Engine/extensions/src/gui-layout/tab-container.ts:55)、[tab-container.ts](D:/HaiyueStudio/Engine/extensions/src/gui-layout/tab-container.ts:76) | Low | S | 取得 content frame 后，孤立 UTF-16 代理项页 ID 在 encodeURIComponent 处抛 URIError；当前 entry 尚未登记，catch 无法释放。之后合法 ID 也不能重用该内容。 | 先验证／编码派生 ID，再获取资源；每份已获取租约立即加入回滚集合，不依赖完整 entry 构造成功。保留合法 Unicode 身份。 |
| F21 | RESOLVED | GUI 预备／无用查询 | [GuiSystem.ts](D:/HaiyueStudio/Engine/engine/src/gui/systems/GuiSystem.ts:966) | Low | S | 固定宽度、autoWidth=false 的标签仍查询字体版本和 resolved skin，而结果只供未进入的 autoWidth 分支。128／256／512 标签分别产生同量的两类查询。 | 把标签查询移入 autoWidth 且非布局托管的条件，保留 HelpDialog 度量及公开可变树的兼容遍历。 |
| F22 | RESOLVED | HYA 解析／分配预算 | [validation.ts](D:/HaiyueStudio/Engine/animation-spec/src/validation.ts:516)、[validation.ts](D:/HaiyueStudio/Engine/animation-spec/src/validation.ts:1213) | Medium | M | maxPathValues=6 的输入，仍先将 12,000 个值转为 Float32Array（48,000 B），再返回正确的超限错误。小预算未阻止超预算转换和数值扫描。 | materialize 前按原数组长度预扣剩余聚合预算，再验证并转换；保持错误 code/path、有限数校验及 copyFloatData:false 的零复制语义。 |
| F23 | RESOLVED | HYA 稀疏变化／几何快照 | [ProductionCoreDrawPlan.ts](D:/HaiyueStudio/Engine/extensions/src/animation/production/ProductionCoreDrawPlan.ts:53)、[ProductionDrawOwner.ts](D:/HaiyueStudio/Engine/extensions/src/animation/layout/production/ProductionDrawOwner.ts:70) | Medium | M | 128 shape 只修改第一个颜色，仍执行 128 次 positions.slice，复制 4,096 B 位置数据，再由 reuse 比较并丢弃相同副本。无变化帧为 0 次复制，问题限定稀疏呈现变化。 | 区分几何与颜色／变换版本，在编译前复用 owner 的不可变几何快照；保持旧帧、pending recording 和回滚隔离，不能直接借用可变 runtime 数组。 |
| F24 | RESOLVED | HYA 语义／隐藏继承 | [SemanticsRuntime.ts](D:/HaiyueStudio/Engine/extensions/src/animation/interaction/SemanticsRuntime.ts:8)、[parser.ts](D:/HaiyueStudio/Engine/animation-spec/src/semantics/parser.ts:7) | Medium | M | parser 接受合法 child-first 数组，runtime 却只继承本轮已见父节点的 hidden。交换两节点顺序，隐藏按钮由正确拒绝变为进入导航、并接受宿主 tap。 | 按已校验 parent graph 内部父先子求值或 memoize 祖先状态；最终仍按 readingOrder／navigationOrder 排序，不能突然拒绝原本合法的 child-first 文档。 |
| F25 | RESOLVED | Material Graph／重复扫描 | [parser.ts](D:/HaiyueStudio/Engine/shader-language/src/graph/parser.ts:88)、[parser.ts](D:/HaiyueStudio/Engine/shader-language/src/graph/parser.ts:264) | Medium | S | 每个节点都从 JSON 开头正则定位，再截取前缀分行。1,024 节点文档仅 280,940 字符，前缀累计处理 143,763,917 字符；metadata 中同名 id 还会让定位指向 metadata 行。 | 单次建立节点位置与行起点索引，避免按节点重复全文搜索；以结构路径识别节点，保持 source provenance，不引入第二套图语义。 |
| F26 | RESOLVED | Material Graph／递归上界 | [materialCompiler.ts](D:/HaiyueStudio/Engine/shader-language/src/graph/materialCompiler.ts:352)、[materialCompiler.ts](D:/HaiyueStudio/Engine/shader-language/src/graph/materialCompiler.ts:201) | Medium | M | 同一种合法 multiply 链在 32／512 节点可编译，8,192 节点、1,251,478 B 则返回 E_MATERIAL_GRAPH_COMPILE／Maximum call stack size exceeded。图遍历和 lowering 依赖 JS 调用栈，实际失败阈值受运行环境／JIT 影响。 | 以有界显式栈建立拓扑序，lowering 复用节点索引与已算结果，保持 cycle／reference 诊断。若需要新增节点或深度限制，应另作合同决策，不能只 catch RangeError。 |

每项原始证据及结构化信息见 [findings.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261126/repeat/findings.json)。编号是追踪身份；实施顺序按下面五组安排，不按文件数量安排。

## 本轮五组实施依据（已完成）

1. **F16：父身份进入变换缓存。** 在 TransformStore 与 Transform2D／3D 协作处使用 parent identity + parent revision + local revision；同版本换父必须重算，仍保留静态节点早退。补父值相同／不同版本、根与子树换父、空间索引的行为测试。
2. **F18、F24：变更由消费者读取，层级按依赖求值。** BitmapText 每份缓存记录已消费 revision；Semantics 在内部拓扑序传播祖先 hidden，发布顺序仍用原 reading／navigation order。分别补双 entity／双 renderer 和节点数组排列对照，禁止隐藏动作。
3. **F15、F17：补齐现有异步资源 owner。** PBR 每槽请求代次，Bitmap atlas 每字体／renderer 请求身份与销毁标记；只有最新且存活的请求可安装。测试等待中淘汰、A→B→A、销毁后返回、自有／借用 bitmap 和 pending submit。继续使用 AssetManager／RecordedGpuResources 的现有归属。
4. **F19、F20：取得即登记，清理到底再报告错误。** 将所有已获取 frame lease 即刻压入回滚集合；dispose 提前失效防重入，每份独立 release 都执行，最后聚合应用观察者异常。保留借用内容唯一 owner 检查。
5. **F22、F23：把省成本动作放在昂贵工作之前。** 路径预算先检查长度再分配；core 几何快照先验证身份再复制。补超限分配计数、颜色／变换稀疏变化、真实 morph、旧帧与回滚矩阵；不能通过删除不可变快照隔离获得改善。

## 低成本优先项

- [x] **F25（Medium／S）**：一次建立结构化节点位置／行索引，替代逐节点全文搜索；加入 JSON 与对象编译等价、metadata 同名 id 和 128／256／512／1,024 节点工作量检查。

F20、F21 也是局部改动，但严重度为 Low，优先级低于上述正确性与资源项。

## 看起来不好，但实际合理（本轮）

- [AssetManager.ts](D:/HaiyueStudio/Engine/engine/src/assets/AssetManager.ts:207) 对共享 pending URL 返回独立消费者 handle、refs=2 是正确租约合同；F15 应补 PBR 身份，不能把资产引用强行合并为一次。
- [ProductionDrawReuse.ts](D:/HaiyueStudio/Engine/extensions/src/animation/layout/production/ProductionDrawReuse.ts:23) 复用前保留不可变 generation、隔离未提交帧有必要。F23 应缓存不可变快照，不能让旧帧引用会变化的 runtime 数组。
- [List.ts](D:/HaiyueStudio/Engine/extensions/src/gui-collections/List.ts:129) 的嵌套 slot 查找只覆盖最多 256 个活跃窗口实例，并非扫描所有 100,000 个逻辑项；不据形式上的二重循环要求重写虚拟化。
- [GuiThemeOwner.ts](D:/HaiyueStudio/Engine/engine/src/gui/GuiThemeOwner.ts:112) 与 [GuiPrimitiveTree.ts](D:/HaiyueStudio/Engine/engine/src/gui/GuiPrimitiveTree.ts:48) 对自定义 provider／getter、图片／nine-slice 的完整回退有可变输入合同原因；不能为所有情况 O(1) 删除它。
- [ScriptComponent.ts](D:/HaiyueStudio/Engine/engine/src/components/ScriptComponent.ts:77) 明确区分 disabled／trusted-project／custom-isolate，[ScriptComponent.ts](D:/HaiyueStudio/Engine/engine/src/components/ScriptComponent.ts:439) 的可配置编译器用于项目脚本；仅见 new Function 不足以断言不可信 Graph JSON 可执行代码。未据关键词报告一个不存在的注入缺陷。

## 修复前复审的覆盖与限制

以下保留最初复审口径；修复后的完整验证以上方修复记录及新凭据为准。

| 维度 | 结论 |
| --- | --- |
| 架构／一致性 | 新缺口集中于请求身份、consumer revision 与异常清理，而非缺少大框架；边界、模块、架构和 renderer 检查通过。模块 resolver 既有 .js→.ts 覆盖限制仍保留，未据此编造实际循环。 |
| 类型／输入合同 | 五 workspace 的现有 typecheck 均通过。F22、F24、F26 是类型检查不能保证的运行时边界／求值问题。 |
| 测试 | 本轮执行 51 项政策与 62 项 GUI／输入现有测试，及 7 个独立复现。初次符号链接用例被 Windows 权限拦截，恢复权限后原两项归档测试通过；原日志保留。未重跑全仓 build／test 或覆盖率；本机无 c8／knip／madge，未安装额外工具。 |
| 性能／资源 | 只报告实际查询、TypedArray、顶点、引用与复制计数；无 GPU 硬件计时、正式 CPU P95／FPS 或新性能基线。未降低预算、样本量或图像容差。 |
| 依赖／配置 | 本轮官方 npm audit=0；受限网络初次失败已保留，授权网络重试成功。未 npm install／audit fix，也未改锁文件。 |
| 错误／安全 | 捕获了 GUI 清理中断和 Graph 通用栈溢出。有限的代码／凭据特征检查没有额外支持的高危发现；不是渗透或专门秘密扫描，不给安全认证结论。 |
| 文档 | F14 保持已修复；旧 README 的版本背景不单列运行时缺陷，当前行为以代码／现行合同和本轮源码哈希为准。 |

输入快照覆盖 **2,125 份文件**，复现前后产品输入完全一致；上一批 29 份具名修复文件亦与凭据一致。见 [crosscheck-result.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261126/repeat/crosscheck-result.json)、[checks.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261126/repeat/checks.json) 和 [retry-checks.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261126/repeat/retry-checks.json)。本轮不替代发布资格，也没有实际推送／发布操作。

## 待维护者明确的问题（本轮）

- Material Graph 的生产最大节点／边数和嵌套深度是否需要明确合同？F26 可以先用显式栈消除隐式调用栈限制；新增拒绝上界应独立评审，不能擅自把当前合法文档改为失败。
- 公开 BitmapFontData、GUI style／children 和 HYA 几何继续可变时，哪些 owner 可提供显式 revision？先保留精确比较退路；managed／immutable 选择仍需要公开合同决策。
- **已修复的独立测试债**：原 hya-production-contract 空 cubism 目录误报现通过真实入口及归属别名校验消除，原始失败和冻结合同保留，详见上方修复记录。

## 历史修复与首轮证据

以下保留 F01–F14 的修复和首轮分析；其中源码基线及测试数量为各历史批次口径。复审前原报告另存为 [audit-before-repeat.md](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261126/repeat/audit-before-repeat.md)，SHA-256 为 43d37012ac480e7a18bb4834c526c217da4556af48e74b63796e73107385e184。

## F01–F04 修复记录（2026-11-25）

| ID | 状态 | 已实施的修复 |
| --- | --- | --- |
| F01 | RESOLVED | [Mesh3DRenderer.ts:1144](D:/HaiyueStudio/Engine/engine/src/renderer/Mesh3DRenderer.ts:1144) 为 base／emissive 分别记录请求代次，材质销毁先标记 disposed，迟到或过时 handle 立即释放；同时覆盖 A→B→A 的同源乱序返回。已录制资源继续按原有 RecordedGpuResources 退休。 |
| F02 | RESOLVED | [AnimationTargetLifetime.ts:15](D:/HaiyueStudio/Engine/extensions/src/animation/AnimationTargetLifetime.ts:15) 成为 mask／effect 共用的私有退休协作者，统一录制引用、submit／cancel、队列完成、设备丢失与幂等释放；捕获资源创建时的 tracker。恢复／销毁清空当前索引，待退役资源仍由协作者持有。 |
| F03 | RESOLVED | [World.ts:883](D:/HaiyueStudio/Engine/engine/src/ecs/World.ts:883) 对 token×entity 的匹配组件计数，只有最后一份匹配离开才删除实体索引，涵盖同类多组件、派生类及共享 symbol。 |
| F04 | RESOLVED | [World.ts:905](D:/HaiyueStudio/Engine/engine/src/ecs/World.ts:905) 以 owner×component 合并 typed journal 更新。单 owner 保留直接记录快路径，遇共享 owner 才提升为 owner map；ring 淘汰维护对应索引，继续保留溢出重同步与独立消费者游标。 |

修复已应用于 `D:/HaiyueStudio/Engine`。验证使用基于 65e9458 的独立目录 `D:/HaiyueStudio/Engine-audit-fixes-20261125`；四份运行时源码与三份新增测试共七个文件，逐文件 SHA-256 均与主工作区一致。主工作区原有的其他改动保持。

验证结论：

- 新增 **20 项回归**，全部通过。最先加入的 17 项先在未修改的发布产物上确认全部失败，再验证修复；另外三项覆盖恢复、设备丢失与同步队列失败。
- 全仓 `npm run typecheck` 与 `npm run build` 通过；生产构建完成 113 个示例／共享输出目标。公共 API、严格类型／错误合同、模块／workspace 边界、职责、架构与 renderer prepare 检查通过。
- 四个 workspace 的全量测试 **2,752 项：2,751 通过，1 项基线已有失败，0 跳过**。随后单独执行示例 catalog 和听音配置单元测试，另外 8 项通过。
- Windows Chrome 157／D3D11 实际 WebGPU 定向 **7 项通过**：Basic 两纹理槽迟到及过时请求释放；效果＋遮罩在 1×／4×MSAA 和 resize 前后的四组像素对照最大差异均为 0；真实 RenderPipeline 取消 resize 后纹理数 9→9；最终 GPU 跟踪资源、owner 和残留为 0，验证错误为 0。
- Engine 本地 tarball 为 **2,050,279／2,100,000 B**，Extensions 为 **597,044／600,000 B**，解包预算也通过；API、预算、基线和着色器均未调整。此为本地修复验证，不是新发布资格或性能基线。

唯一全量测试失败为 [hya-production-contract.test.mjs:19](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/test/hya-production-contract.test.mjs:19)：冻结清单包含 `animation-spec/src/cubism`，但目录为空，Git 未保存，因此干净 checkout 的目录枚举少一项。在**未修改的 65e9458** 上运行同一测试也失败；旧发布工作目录中残留该空目录，解释了两种环境差异。此次未改该合同、未补空目录，保留为独立的后续测试债。

完整文件哈希、包哈希、测试计数与 WebGPU 结果见 [fix-validation-result.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261125/fix-validation-result.json)。原始失败、受限环境的权限失败、修复后日志及未修改基线的合同复现均保存在同一审计目录。

## F05–F08 修复记录（2026-11-25）

| ID | 状态 | 问题、方法与结论 |
| --- | --- | --- |
| F05 | RESOLVED | JSON／compact binary 共用 [validateCompositeGraph](D:/HaiyueStudio/Engine/animation-spec/src/validation.ts:1166) 的显式栈三色遍历，栈容量由已校验节点数确定。100／20,000 节点无环链可解析；深环仍返回原格式 code／path，失效引用、节点数和输入字节限制保持。此结论只覆盖格式校验，不声称任意深度渲染已获支持。 |
| F06 | RESOLVED | [layoutGuiElementSelf](D:/HaiyueStudio/Engine/engine/src/gui/GuiLayoutState.ts:63) 只安排自身矩形；滚动容器在最终 offset／内容坐标下遍历孩子一次。1／2／4／8 层嵌套的叶节点布局由 2／4／16／256 次统一降为 1 次。保留 assigned／retained rect、横纵向 clamp、隐藏节点及 viewport 通知。 |
| F07 | RESOLVED | [binding.ts](D:/HaiyueStudio/Engine/extensions/src/gui-layout/binding.ts:65) 默认测量复用本次 arrange 的 byId Map，仍交 root.measureElement 校验归属。索引在 finally 中恢复，支持嵌套和异常后重试；自定义测量不变。512 个叶仍执行 513 次必要测量，递归查找访问由 132,354 次降为 0。 |
| F08 | RESOLVED | [GuiTextBatch.ts](D:/HaiyueStudio/Engine/engine/src/gui/rendering/GuiTextBatch.ts:123) 复用原字形／字距循环生成前缀宽度，[GuiInputPresentation.ts](D:/HaiyueStudio/Engine/engine/src/gui/input/GuiInputPresentation.ts:35) 共用行度量处理命中、光标和选区。单调阈值二分，非单调字距保留首次命中规则。512 字符末尾命中字形查询由 262,144 次降为 512 次；Unicode 字素、CRLF、实时字体变化及自定义 renderer 度量回归通过。缓存有界且会检查可变字体身份；无法安全缓存时仍线性重算。 |

修复已写入主工作区；10 份运行时文件和 4 份新测试与独立验证目录逐文件 SHA-256 一致。主工作区三份原本较旧且没有未提交修改的 GUI 文件（GuiElement、GuiLayoutState、布局 binding）同时保留了已发布实现的空 skin 快路径、嵌套 assignment scope 和布局结果缓存合作规则。F01–F04 的全部七份源码／测试哈希与上一批凭据一致，其他原有改动保留。

验证结论：

- 新增 **21 项回归**，全部通过；前 20 项先在未修复 F05–F08 的实现上运行，13 项失败、7 项通过，另补一项已发布的嵌套 assignment 恢复不变量。合并既有 GUI／布局回归的 **77 项定向测试**通过。
- 全仓 `npm run typecheck` 通过；磁盘恢复后 `npm run build` 完成 **113 个示例／共享输出目标**。公共 API、严格类型／错误合同、模块／workspace 边界、职责、架构和 renderer prepare 检查通过。
- 四 workspace 全量 **2,773 项：2,772 通过、1 项原有失败、0 跳过**；唯一失败仍是上一节已在未修改基线独立复现的空 `cubism` 目录清单。示例 catalog 与听音配置的另外 **8 项**通过；未隐藏或修改该失败。
- Windows Chrome 157／D3D11 实际 WebGPU **6 组对照**通过：嵌套滚动＋intrinsic flow＋长输入、滚动后 Unicode 选区、resize，各覆盖 1×／4×MSAA。与未修改发布产物的整帧像素最大差异均为 **0**，光标几何及指针命中一致，GPU 验证错误为 0，四个场景销毁后的跟踪资源均为 0。既有 GUI 缓存门禁 **16 帧**通过。
- 按现行发布白名单、source map 剔除及具名元数据换行规则暂存后，Engine 为 **2,052,354／2,100,000 B**，animation-spec 为 **170,755／190,000 B**，Extensions 为 **597,123／600,000 B**；三包解包预算也通过。animation-spec 未修改参考按同规则为 170,719 B。原始直接 npm pack 的 map 文件与超额结果保留，未将两种打包口径混用。

完整文件／包哈希、结构计数、检查状态及浏览器结果见 [validation-result.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261125/f05-f08/validation-result.json)。此为本地修复验证；API、版本、解析限制、包体预算、像素容差和着色器保持，未建立新的正式性能基线或执行发布。

## F09–F14 修复记录（2026-11-26）

| ID | 状态 | 问题、方法与结论 |
| --- | --- | --- |
| F09 | RESOLVED | [AnimationTextRasterizer.ts](D:/HaiyueStudio/Engine/extensions/src/animation/AnimationTextRasterizer.ts:243) 按已解析文档、样式／尺寸、字体代次及连续动画时间识别像素输入。相同离散文档的 60 次采样保持同一位图，纹理代次为 2，原实现为 122；跨关键帧、反向 seek、表达式、快照保留和异步字体失效仍正确，连续字形动画继续更新。 |
| F10 | RESOLVED | [Mesh3DRenderer.ts](D:/HaiyueStudio/Engine/engine/src/renderer/Mesh3DRenderer.ts:1193) 的四个缺省 morph slot 共用不可变零缓冲，缺失 target 也共享；分配、扩容及退休按唯一资源处理。100,000 顶点该路径由 4,800,000 B 降为 1,200,000 B；多录制的提交／取消仍等待原资源生命周期。 |
| F11 | RESOLVED | [GuiThemeOwner.ts](D:/HaiyueStudio/Engine/engine/src/gui/GuiThemeOwner.ts:64) 复用内置主题输入快照，将普通状态变化与资源／字体变化区分；[GuiPaintCache.ts](D:/HaiyueStudio/Engine/engine/src/gui/rendering/GuiPaintCache.ts:31) 增量维护有序片段。512 控件叶状态只重解析受影响皮肤；64 按钮原生对照中 focus 重绘由 65 元素降为 1。自定义 provider／getter、图片、nine-slice、复杂样式仍完整解析，公开可变树的兼容扫描保留，不声称所有主题更新都为 O(1)。 |
| F12 | RESOLVED | 移除未使用的 textures／texture-compressor 开发依赖链，仅将原 Basis encoder 字节保存在验证夹具中，附 npm 来源、SHA-256 和 MIT／Apache 许可证；[basis-encoder-assets.mjs](D:/HaiyueStudio/Engine/scripts/webgpu-gate/basis-encoder-assets.mjs:1) 在使用前验证长度与哈希。serialize-javascript 7.1.0→7.1.4，兼容原范围，无跨 major override；官方 audit 为 0，原 glTF／KTX2 三档门禁通过。 |
| F13 | RESOLVED | [AudioAssetOwner.ts](D:/HaiyueStudio/Engine/extensions/src/animation/audio/AudioAssetOwner.ts:153) 让 slot 持续拥有 committed lease，候选成功后原子交换。A／B／C 重叠的成功、失败、过时、复用、释放及销毁矩阵通过；旧 handle 恰好释放一次，最终缓存及解码字节归零。此为私有替换路径，不将它误归因为此前公开重听问题。 |
| F14 | RESOLVED | [README.md](D:/HaiyueStudio/Engine/README.md:94) 如实区分手动 master 和自动 push SHA 的 Pages 来源，说明其与签名标签／npm 发布独立。两个工作流保持原样。 |

默认 GUI 装配还消除了对完整主题资源类的提前依赖：内置实例通过私有注册证明身份，输入文本度量器按实际需要创建；快照比较和前缀命中共用小型算法，不增加第二套主题／文本实现。正式安装消费者的 gui-font gzip 为 **94,892／95,000 B**；初次 97,200 B 超额报告保留，原预算未调整。

验证结论：

- 本批 **21 项新增回归全部通过**；全仓类型检查与生产构建通过，构建完成 113 个示例／共享目标。公共 API、错误／严格类型合同、workspace／模块边界、职责、架构及 renderer prepare 检查通过。
- 四 workspace 全量 **2,792 项：2,791 通过、1 项原有失败、0 跳过**；唯一失败仍是前文在未修改 65e9458 上独立复现的空 cubism 目录清单。随后示例 catalog／听音配置另外 **8 项**通过，未补空目录、跳过或改写该合同。
- 四个正式 tarball 的确定性重打包、真实安装、公开导出／声明、运行时和独立消费者检查全部通过，包体与解包预算保持。Engine／animation-spec／Extensions／shader-language 分别为 **2,053,908／170,755／597,266／148,545 B**；完整哈希见凭据。
- Windows Chrome 157／D3D11 的 **14 项实际 WebGPU 对照**通过：主题 focus／hover／替换／resize 覆盖 1×／4×MSAA；零流共享与扩容、离散文字复用及关键帧切换均与冻结参考逐像素一致，最大通道差异 **0**，GPU 错误及六组资源残留均为 **0**。既有 GUI 缓存门禁 **16 帧**和完整 glTF／KTX2 三档门禁通过。
- **29 份源码／测试／依赖／夹具文件**与独立验证目录逐文件 SHA-256 一致；README 仅修正具名段落，两边其他原有差异保留。F01–F08 未重叠文件的哈希仍与原凭据一致。

验证仍使用对齐发布源码的独立目录 Engine-audit-fixes-20261125；主工作区较旧 HEAD 及其他原有修改未被重置。API、版本、全部预算、像素容差、发布工作流和历史失败记录保持。本次是本地修复验证，未建立正式性能基线，未提交、推送或发布。

完整输入／产物哈希、包消费者、测试与浏览器结果见 [validation-result.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261125/f09-f14/validation-result.json)；原失败及修复后日志保留在同目录。

## 首轮基线与架构模型（历史）

主审源码为 `D:/HaiyueStudio/Engine-release-024-docs-20261124`，提交 **65e9458d7568f5ec7ca8317351cde1829f71eac0**。它与发布运行时 **c744e8323b2848178ad8f487e36968ac5fe263b2** 仅有五份文档／验收索引差异，运行时代码一致。原始发现的源码链接指向该主审目录，修复记录链接指向主工作区。

`D:/HaiyueStudio/Engine` 当前仍是较旧 HEAD 加未提交工作，不能代表完整发布代码。报告写在该目录供后续处理。F01–F04 涉及的原始文件已确认与发布源码一致，并以独立的 65e9458 副本验证同一修复；未覆盖、重置或提交其中的其他已有修改。

架构实际由三个独立基础包和一个可选能力包组成：`engine` 持有 Scene/ECS、WebGPU 帧与视图、GUI 输入和资源归属；`animation-spec` 持有 HYA 格式、校验、二进制与转换；`shader-language` 在构建期将前端降到 Typed IR，再生成 WGSL。`extensions` 通过公开子入口消费基础能力，提供布局、集合、HYA、音频、叙事与视觉小说装配。示例是公开包消费者，测试、采样与发布脚本构成独立的验证层。

应统一的是**生命周期和身份规则**，并非把这些层合成一个大框架。此次重复实现造成的实质问题，是 Basic/PBR 材质的迟到结果规则、effect/mask 目标的退役规则已经分叉。GUI 和 HYA 虽都呈现文字，却各有不同的字体、动画与快照合同；适合共享纯度量数据及局部算法，不适合合并输入、采样或资源 owner。

已读取 README、manifest、各范围 AGENTS、相关 ADR，并分析最近 200 条提交及六个月变更。统计 2,781 个代码／测试／工具文件、374,903 行，排除生成物、vendor 和构建目录；**这不是纯运行时 LOC**。最大文件与高变更交集集中在动画运行时、动画渲染、Render3DSystem、GuiSystem。完整前 20 大文件与前 20 高变更文件见 [orientation.json](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261125/orientation.json)。文件行数和文件数量均不作为缺陷判据。

## 首轮发现（F01–F14，均已修复）

下表保留原始发现及建议；F01–F14 状态均为 RESOLVED，详见修复记录。严重度表示原始触发条件下的影响；工作量 S 为局部修正，M 为跨协作者和回归矩阵，L 为需分阶段演进。表中“优化机会”不表示当前已违反正式性能预算。

| ID | 类别 | File:Line | 严重度 | 工作量 | 问题、触发与影响 | 建议 |
| --- | --- | --- | --- | --- | --- | --- |
| F01 | 资源生命周期／确认缺陷 | [Mesh3DRenderer.ts:1141](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/renderer/Mesh3DRenderer.ts:1141)、[销毁:1435](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/renderer/Mesh3DRenderer.ts:1435) | High | M | 材质在异步纹理完成前被单独淘汰，renderer 仍存活；回调只检查 renderer 和 source，继续安装到已移出缓存的数据。复现缓存为 0、handle 释放次数为 0，仍重建 bind group，可能引用已退休 buffer。 | 材质记录持有 disposed／请求代次；销毁先失效，迟到 handle 立即释放。复用 PBR 的生命周期规则，保持提交后退休。 |
| F02 | 资源生命周期／确认缺陷 | [Animation2DRenderSystem.ts:1235](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/src/animation/Animation2DRenderSystem.ts:1235)、[清扫:1271](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/src/animation/Animation2DRenderSystem.ts:1271) | Medium | M | effect resize／淘汰时先移出 map，仅注册 afterSubmit 释放。该录制被取消后旧目标失去归属；释放当前目标仍遗留两张旧纹理。1080p RGBA8 一对约 15.8 MiB，重复取消会累积。 | effect 和现有 mask 共享私有目标退休协作者，跟踪录制引用、提交／取消和队列完成。不能简单在 cancel 时立即销毁其他录制仍引用的目标。 |
| F03 | ECS 身份／确认缺陷 | [World.ts:824](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/ecs/World.ts:824) | Medium | M | 一个 entity 的 A/B 共同匹配 Base，移除 A 后无条件删掉 token 对应实体索引；仍有 B，hasComponent(Base) 为 true，但 indexed candidates 和新安装 System 都为 0。同类多组件和共享 symbol 也受此规则影响。 | token×entity 维护匹配引用计数，最后一份匹配组件移除时才删索引；验证 all／any、派生类、重复组件和重装系统。 |
| F04 | 增量传播／确认缺陷 | [World.ts:763](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/ecs/World.ts:763)、[空间消费者:231](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/spatial/SpatialIndexService.ts:231) | Medium | M | typed journal 仅按 component.id 合并更新，并覆盖 pending.entity。共享 Mesh3D 的 A/B 改 geometry 后只保留 B 更新，A 的空间 bounds 留在旧位置，可能使射线／裁剪候选错误。 | 按 entity.id×component.id 合并；同一 pair 的连续更新继续压缩，保留多消费者非破坏式读取和有界 ring buffer。 |
| F05 | 输入边界／错误合同／确认缺陷 | [validation.ts:1161](D:/HaiyueStudio/Engine-release-024-docs-20261124/animation-spec/src/validation.ts:1161)、[binary.ts:764](D:/HaiyueStudio/Engine-release-024-docs-20261124/animation-spec/src/binary.ts:764) | Medium | M | composite DFS 递归深度不受现有节点限制保护。20,000 节点无环链低于默认 100,000 节点：约 1.52 MB JSON 和 0.95 MB binary 均抛裸 RangeError／Maximum call stack size exceeded，失去格式错误 code/path。 | 改显式栈三色 DFS；JSON 与 compact binary 共用遍历策略。补深链、环、无效引用和数量边界；不靠 catch RangeError 伪装成功。 |
| F06 | GUI 布局／确认重复工作 | [GuiScrollView.ts:121](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/gui/components/GuiScrollView.ts:121)、[GuiElement.ts:237](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/gui/components/GuiElement.ts:237) | Medium | M | super.layout 已遍历 children，随后 layoutContent 再遍历。嵌套 1／2／4／8 层时，单叶布局分别执行 2／4／16／256 次；窗口改变或内容变更触发成倍重复。 | 提取只安排自身矩形的内部方法，普通元素和滚动元素各在最终内容坐标下安排 children 一次；保持 assigned rect、clamp、viewport 事件。 |
| F07 | GUI 布局／确认算法瓶颈 | [binding.ts:20](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/src/gui-layout/binding.ts:20)、[已有索引:72](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/src/gui-layout/binding.ts:72) | Medium | S | 默认 intrinsic measure 每次 root.findById 递归查树，同次 arrange 已建 byId 却未复用。512 个 auto-height 叶产生 513 次 measure 和 132,354 次节点查找。首次布局、字体／auto size 变化形成 O(N²) 查找。 | 默认测量在 arrange 期间复用已有 Map；保持自定义 measure 和 root.measureElement 归属校验，不额外复制一棵树。 |
| F08 | GUI 文本／确认算法瓶颈 | [GuiInputPresentation.ts:59](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/gui/input/GuiInputPresentation.ts:59)、[线性度量:108](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/gui/rendering/GuiTextBatch.ts:108) | Medium | M | indexAt 遍历 grapheme，反复 measure 两个增长的前缀；实际字体度量再逐字遍历，长文本末尾命中为 O(L²)。512 字符命中调用 measure 1,024 次、累计 262,144 个前缀字符，拖选可反复触发。 | 同一行生成并复用 grapheme 边界与前缀 advance，二分命中；caret、selection 共用 metrics run，身份包含文本和字体／kerning 代次。 |
| F09 | HYA 文本／优化机会 | [AnimationTextRasterizer.ts:133](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/src/animation/AnimationTextRasterizer.ts:133)、[时间更新:182](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/src/animation/AnimationTextRasterizer.ts:182)、[位图:235](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/src/animation/AnimationTextRasterizer.ts:235) | Medium | M | 只要 documents 多于一个即按时间刷新。t=0 为 A、t=10 为 B，在前 1 秒内文档完全相同，60 帧仍重画并额外生成 60 张 ImageBitmap，推动纹理代次更新。 | 无连续 animator 路径按采样内容、字体、样式、状态和尺寸判断是否重画；区分 shaping／分行缓存和真正逐字动画，保留快照与 whenReady 规则。 |
| F10 | GPU 内存／优化机会 | [Mesh3DRenderer.ts:1179](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/renderer/Mesh3DRenderer.ts:1179) | Medium | S | 无 morph 几何仍为四个输入 slot 创建四份相同零流。100,000 顶点该路径分配 4,800,000 B，实际一份只需 1,200,000 B。 | 四个 slot 绑定同一 immutable 零缓冲，按唯一资源释放；扩容和 pending recording 仍遵守原退休规则。 |
| F11 | GUI 失效／优化机会 | [GuiThemeOwner.ts:43](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/gui/GuiThemeOwner.ts:43)、[GuiRenderer.ts:314](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/gui/rendering/GuiRenderer.ts:314) | Medium | M–L | 有 theme resource 的 focus／hover 路径仍同步解析整树，并退出 retained paint cache。512 个按钮仅末个按钮 focus 产生 2,050 次 resolve。stock primitive 的现有增量快路径已有，问题限定为主题状态路径。 | 先分离主题资源版本／继承变化与单控件状态变化；只重算实际依赖，再增量维护 ordered paint spans。生产主题界面实测后再决定第二阶段。 |
| F12 | 依赖／安全维护 | [开发依赖:71](D:/HaiyueStudio/Engine-release-024-docs-20261124/package-lock.json:71)、[image-size:1597](D:/HaiyueStudio/Engine-release-024-docs-20261124/package-lock.json:1597)、[serialize:1878](D:/HaiyueStudio/Engine-release-024-docs-20261124/package-lock.json:1878) | Medium | M | 锁定的 textures→texture-compressor→image-size 0.7.5 链落入 ICNS 死循环公告；serialize-javascript 7.1.0 也有 Low 公告。前者来自 Engine devDependencies，未在普通 runtime 发现 ICNS 处理路径。 | 优先评估验证夹具能否只保留必需、带哈希的 Basis encoder 资产，移除不使用的压缩 CLI 依赖链，或等上游兼容修复；serialize 在兼容范围更新并验证。勿强制跨 major override。 |
| F13 | 私有音频生命周期／确认缺陷 | [AudioAssetOwner.ts:139](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/src/animation/audio/AudioAssetOwner.ts:139) | Low | M | 已加载 A，替换 B 尚未完成又替换 C；旧 A 的 digest 只存在 B 的局部变量中，B 过时代次既不恢复也不释放。releaseResource 后仍有缓存，直到 owner dispose。当前公开 HyaAudio 未暴露 replace，因此不归因为此前公开重听问题。 | slot 分开持有 committed lease 和 pending candidate；成功时原子交换，过时代次只清理自己。补已有缓存下的重叠替换矩阵。 |
| F14 | 文档漂移／确认不一致 | [README.md:94](D:/HaiyueStudio/Engine-release-024-docs-20261124/README.md:94)、[手动 workflow:24](D:/HaiyueStudio/Engine-release-024-docs-20261124/.github/workflows/deploy-pages.yml:24)、[CI workflow:24](D:/HaiyueStudio/Engine-release-024-docs-20261124/.github/workflows/deploy-pages-ci.yml:24) | Low | S | README 仍称站点由人工选择且验证签名的 release tag 构建；实际手动入口 checkout master，CI 则在 master push 时 checkout github.sha。读者会误判站点来源与发布冻结关系。 | 据现行部署政策修正文档并增加说明／检查；若仍要求签名 tag，则另行批准恢复该行为。不能在文档修复中悄悄改变部署范围。 |

## 原始审计的五项优先建议（已实施）

### 1. 收敛 GPU／资产生命周期规则（F01、F02）

Basic 材质记录增加 `disposed` 和请求身份：开始异步操作时捕获身份；销毁时先置位／失效；成功回调仅在 owner 和身份仍匹配时安装，否则释放返回 handle。可参考 [PbrMaterialResources.ts:229](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/renderer/PbrMaterialResources.ts:229) 与 [销毁:287](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/renderer/PbrMaterialResources.ts:287)，统一必要的纯状态规则，不合并两种材质的具体 shader／packer。

effect 目标采用 mask 已有的 `recordings + retired + submitted` 归属模型，参见 [Animation2DRenderSystem.ts:1305](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/src/animation/Animation2DRenderSystem.ts:1305)。map 只索引当前目标，独立 retired 集持续拥有待释放目标；取消关闭录制引用，已提交目标等队列安全后释放。

验收：材质单独淘汰／整个 renderer 销毁、纹理换源、resize 后取消、多上下文引用、队列拒绝、最终资源归零。现有 [renderer-resource-lifecycle.test.mjs:462](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/test/renderer-resource-lifecycle.test.mjs:462) 只覆盖整体销毁的迟到结果；[animation-mask-submission.test.mjs:15](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/test/animation-mask-submission.test.mjs:15) 的取消矩阵应扩到 effect。

### 2. 让 ECS 索引和 journal 使用正确的身份粒度（F03、F04）

索引结构从 `Map<Token, Set<Entity>>` 的无条件删除规则，演进为“最后一个匹配组件离开才删实体”。可用匹配计数，避免每次 detach 全量重扫。journal 从单一 `component.id` 键改为 owner×component，保留同一 pair 的更新合并、ring 容量和各 consumer 的独立游标。

验收：兄弟派生类、同类多组件、共享 symbol、共享 Mesh3D 的几何替换、all／any、新装 System、空间查询、LOD 与 GPU-driven 消费。保留 [spatial-index-service.test.mjs:107](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/test/spatial-index-service.test.mjs:107) 中单实体 9,000 次更新只合并一次的原目标。

### 3. 先消除 GUI 布局重复遍历（F06、F07）

内部边界可调整为 `layoutSelf(parentRect)` 与 `layoutChildren(contentRect)`；普通元素调用两者，ScrollView 在自身尺寸和 offset clamp 确定后仅调用一次 children 布局。它不需要另一套布局引擎。默认 measure 在当前 arrange 的已有 `byId` 中取节点，自定义测量和测量归属校验保持原语义。

验收既要保留滚动、焦点 reveal、assigned rectangle 和像素结果，也要加**结构工作量断言**：一轮布局每个活跃叶的访问保持线性，默认测量不再递归 findById。现有 [gui-focus-navigation.test.mjs:138](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/test/gui-focus-navigation.test.mjs:138) 的嵌套几何验证通过，仍未约束这部分工作量。

### 4. 将 HYA 合成图校验改为显式栈（F05）

复用现有三色状态，栈帧记录节点及下一条边。遇 active 节点仍精确报告 cycle，完成后标记 done；避免 JS 调用栈成为隐含格式限制。JSON 和 compact binary 的图表示可分别适配到同一个私有遍历内核，错误 path 由各自 adapter 生成。

验收 100／20,000 节点无环链、深链末端环、失效 source、原有 maxNodes 与输入字节上界。实际下游若不支持如此深的合成嵌套，应另行定义显式深度限制并返回格式错误，不能依赖运行环境随机栈溢出。本报告未声称下游任意深度渲染已经受支持。

### 5. 以稳定内容身份缓存文字工作（F08、F09）

GUI 输入为一行创建 `grapheme boundaries + advances + metrics generation`，命中用前缀数据二分，caret 与 selection 共用。字体对象可变，不能只用文本字符串作永久 key。

核心 HYA `text2d` 先采样，比较最终文档／样式／字体／状态／尺寸身份；离散关键帧间相同则沿用位图代次，连续 animator 仍逐帧更新。参见 [AnimationTextRasterizer.ts:182](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/src/animation/AnimationTextRasterizer.ts:182)。保留布局文本已有缓存，不将其重写为第二份 shaping 系统。

验收 emoji／组合字、密码映射、滚动末尾拖选、实时字体变化，以及离散字幕关键帧间位图代次不变、到边界仅更新一次；连续选择器和晚到位图释放继续通过。

## 首轮低成本项（已实施）

- [x] **F07**：默认 intrinsic measure 已复用当前 arrange 的节点 Map，并加入工作量及异常后恢复断言。
- [x] **F10**：四路缺省 morph 已复用一份零缓冲，扩容、释放去重及 pending/cancel 回归通过。
- [x] **F12**：serialize-javascript 已兼容更新；texture-compressor 链已移除，以带哈希与许可证的固定夹具资产替代。
- [x] **F14**：Pages 来源说明已按现行两个工作流修正，部署范围保持。

## 看起来不好，但实际合理（首轮）

1. **大协调文件不等于必须继续拆分。** [Render3DSystem.ts:644](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/systems/Render3DSystem.ts:644) 已按共享帧输入提取，再派生各视图准备；各 collector／preparation／submitter 有独立 owner。没有证据支持为行数拆碎或回到多份渲染实现。
2. **pending recording 时复制／新建 GPU 缓冲是必要成本。** [RendererObjectTable.ts:294](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/renderer/RendererObjectTable.ts:294) 与 [GuiGpuResources.ts:34](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/gui/rendering/GuiGpuResources.ts:34) 防止后续 CPU 帧覆盖未提交 draw 所见数据。应去掉 F10 的同内容重复资源，不能取消提交生命周期隔离。
3. **GUI topology 扫描仍有合同原因。** [GuiDirtyState.ts:24](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/gui/GuiDirtyState.ts:24) 支持公开 children 数组直接变化及自定义 live getter。未经 API 改动，不能仅靠 mutation journal 跳过检查。可以探索 managed-tree 的显式选择，而不是偷偷改变当前语义。
4. **主题 GUI 的 painter order 不能被“批处理优化”打乱。** [GuiPaintPlan.ts:15](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/gui/rendering/GuiPaintPlan.ts:15) 保证 shape／image／text 交叠顺序；F11 应增量维护有序结果，而非按材质跨控件重排。
5. **VN 换素材时重建后续槽位有层序原因。** [VisualNovelStage.ts:314](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/src/visual-novel/stage/VisualNovelStage.ts:314) 只复用不变 painter prefix，避免替换角色盖住应在其上的效果；编码资产也已有共享。不能仅按 asset 相同就固定复用原 Player 的注册位置。
6. **prepare／commit／publish 分层不是重复运行时。** [FrameTransaction.ts:94](D:/HaiyueStudio/Engine-release-024-docs-20261124/extensions/src/animation/production/FrameTransaction.ts:94) 区分内部提交失败和宿主发布异常，防止事件重复投递；保留此边界。HYA 全实体 JSON revision 可做后续 profile，但本次未证明它成为瓶颈，不列正式问题。
7. **unknown 边界和格式 adapter 不等于类型债。** 当前 untrusted graph／HYA 边界先做校验，统一 IR 和结构错误已有实现。未发现需要再造一套通用校验／日志框架的证据。应修复 F05 的具体逃逸路径。

## 依赖公告及实际暴露范围

原始审计的 `npm audit --package-lock-only --ignore-scripts --json` 成功获取官方数据；退出码 1 表示存在公告。当时报告为 high 3、low 1，**high 3 是同一条传递链的三个节点**。以下保留原始暴露分析；F12 修复后的报告为 0，见本批验证凭据。

- `@loaders.gl/textures@4.4.4 → texture-compressor@1.0.2 → image-size@0.7.5`：落入 [GHSA-w3rx-r6r6-pgpr](https://github.com/advisories/GHSA-w3rx-r6r6-pgpr)，特制 ICNS 可造成 Node 解析死循环；公告修复版为 2.0.3。仓库中此链来自开发依赖，当前验证路径引用的是 Basis encoder JS/WASM 资产，见 [gltf-corpus-fixture.mjs:73](D:/HaiyueStudio/Engine-release-024-docs-20261124/scripts/webgpu-gate/gltf-corpus-fixture.mjs:73)。未证明普通引擎运行时或该夹具实际可到达 ICNS 解析；不建议直接跨 major override。
- `@rollup/plugin-terser@1.0.0 → serialize-javascript@7.1.0`：落入 [GHSA-m5mm-p8h7-m29v](https://github.com/advisories/GHSA-m5mm-p8h7-m29v)，修复版 7.1.3。利用还要求可控函数序列化内容嵌入 script；当前构建链不等于已确认网站 XSS。

初次审计未执行 `npm audit fix` 或安装升级；后续 F12 仅实施具名锁文件维护并干净安装验证。原始 audit 与两份 `npm explain` 结果保存在审计证据目录。

## 原始审计的验证、覆盖与限制

| 维度 | 本轮结论 |
| --- | --- |
| 架构 | workspace 边界、594 个 engine 模块的现行循环／反向依赖门禁、Scene 架构门禁通过；不据此断言所有包内路径都经过形式验证。 |
| 一致性 | 主要债集中在 owner 生命周期规则分叉（F01、F02、F13）；未建议统一本来就有不同合同的 GUI 与 HYA owner。 |
| 类型／合同 | 五 workspace 现有 typecheck 通过；F05 是现有类型检查无法检测的运行时错误合同逃逸。 |
| 测试 | 新跑 75 项 parser／Material Graph／发布资产测试和 63 项 GUI 测试，全通过；缺口通过独立 CPU／审计 GPU 计数复现，不等于完成全部回归。 |
| 依赖／配置 | 完成实时 npm audit 与传递链核对，详见 F12；没有因版本较旧就推荐升级整组依赖。 |
| 性能／资源 | 复现实际工作量与资源残留。报告中的布局次数、字符数、位图数与分配字节均为结构证据，**不是 FPS、CPU P95 或 GPU 正式采样结果**。 |
| 错误／可观测性 | 主要具体缺口为 F05 的 RangeError 无格式 code/path；未发现支持全仓替换错误系统的理由。 |
| 安全 | 覆盖解析边界和依赖公告；未进行渗透、专门凭据扫描或 Native 宿主安全审计，不声称不存在其他安全问题。 |
| 文档 | 确认 F14；历史 ADR／失败报告不因实现演进自动判为无用，不进行历史证据清理。 |

实际执行：

```text
npm run typecheck --workspaces --if-present
node scripts/check-workspace-boundaries.mjs
node scripts/check-engine-module-boundaries.mjs
node scripts/check-stage5-architecture.mjs
node scripts/check-renderer-prepare-contract.mjs
node --test --test-concurrency=1 animation-spec/test/animation-spec.test.mjs shader-language/test/material-graph-authoring.test.mjs shader-language/test/stage3-material-graph.test.mjs scripts/publication-assets.test.mjs
node --test --test-concurrency=1 engine/test/gui-invalidation-p0.test.mjs engine/test/gui-incremental-geometry.test.mjs engine/test/gui-text-presentation.test.mjs engine/test/gui-horizontal-scroll.test.mjs engine/test/gui-focus-navigation.test.mjs
npm audit --package-lock-only --ignore-scripts --json
npm explain image-size --json
npm explain serialize-javascript --json
```

类型检查和现有编译后测试使用已安装依赖、运行时代码一致的 `Engine-release-024-20261119`，未重建发布产物。主审目录仅借用其 node_modules junction 供只读源码装载；没有 npm install／ci。四份独立复现脚本分别是 `core-reproductions.mjs`、`gui-structural-probes.mjs`、`animation-proofs.mjs`、`parser-probe.mjs`，均通过；证据索引见 [审计目录](D:/HaiyueStudio/Engine/artifacts/tech-debt-audit/20261125)。

未运行全仓覆盖率、全量构建、真实 GPU／压力测试、设备输入／听音或发布流程；未安装 c8、madge、knip 等额外工具。本轮结果不能替代后续修复的正式资格。模块解析补充检查发现现行门禁未解析一条 `.js` 指向同名 `.ts` 的 value import，见 [resolver:84](D:/HaiyueStudio/Engine-release-024-docs-20261124/scripts/check-engine-module-boundaries.mjs:84)；未据这一覆盖限制宣称已发现真实循环。

## 首轮待维护者问题（历史）

- 是否希望为 managed GUI tree 提供显式模式，从而允许跳过公开数组／live getter 的兼容扫描？这需要新的合同选择，不能以当前 P0 优化名义直接改变行为，相关边界见 [GuiDirtyState.ts:24](D:/HaiyueStudio/Engine-release-024-docs-20261124/engine/src/gui/GuiDirtyState.ts:24)。
- HYA composite 的生产允许嵌套深度应是多少？F05 的校验栈溢出已修复，无限深度渲染仍不是本次已确认的能力；可在格式／播放能力边界明确限制。
- Pages 来源已按现行 master／push 工作流说明，F14 已解决。若未来要求仅签名发布标签，需独立调整工作流和发布资格。

修复建议按资源与 ECS 正确性 → GUI 布局／文本重复工作 → HYA 文本与可选主题优化实施。各批在原门禁、画质和资源合同下复验；本报告不授权改变预算、发布标签或推送代码。
