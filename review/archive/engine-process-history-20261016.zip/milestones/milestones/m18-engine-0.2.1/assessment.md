# 当前能力与后续机会

观察日期：2026-09-25。Engine 源码：`365552908414ffa193c63a62aaf682f4ddb23b94`，`release/0.2.1`，观察时工作树干净。以下是代码与已有报告审查，本轮没有重新执行 GPU 性能测试。

## 已确认事实

| 现状 | 证据 | 对计划的影响 |
| --- | --- | --- |
| 场景总灯光容量为 8，PBR 方向光阴影容量为 3 | [SceneLightData](../../../Engine/engine/src/frame/SceneLightData.ts) | 新路径需要独立 storage ABI，不能只把常量改大 |
| CPU 根据影响力选灯并截断，稳定槽位与 overflow 已有统计 | [SceneLightSelection](../../../Engine/engine/src/frame/SceneLightSelection.ts)、[ViewLightUniformBuffer](../../../Engine/engine/src/renderer/ViewLightUniformBuffer.ts) | Deferred 必须从未截断候选集取灯，绕过旧 8 灯选择器；保留可解释诊断 |
| 128 authored 灯的旧测试仍走受限 Forward | [灯光评审](../../../Engine/review/release-0.2.0-shader-lighting.md) | 旧正式测试通过不代表全部 128 灯被照亮；新增完整覆盖断言 |
| Forward+/CSM 仍是 hold；已有规模化准入原则 | [策略](../../../Engine/config/lighting-architecture-policy.json)、[ADR 0021](../../../Engine/docs/for-ai/adr/0021-benchmark-driven-lighting-shadow-scale.md) | 用户提出的新需求进入 G01 架构评审，分别记录 Deferred 与后续 Forward+/CSM，不能以旧 hold 否定本需求，也不能悄悄解除全部 hold |
| 已有辅助 MRT、资源依赖图和瞬态目标池 | [辅助 MRT 报告](../../../Engine/review/auxiliary-mrt-frame-plan-2026-09-06.md)、[Render3DFramePlan](../../../Engine/engine/src/systems/Render3DFramePlan.ts)、[TransientRenderTargetPool](../../../Engine/engine/src/rtt/TransientRenderTargetPool.ts) | 扩展当前所有者；只在覆盖、空间、格式和采样语义相同的情况下复用，不能把辅助 normal buffer 直接当完整 G-buffer |
| 已有按 pass 的异步 GPU 计时 | [GpuPassProfiler](../../../Engine/engine/src/core/GpuPassProfiler.ts) | 增加实际 G-buffer/cull/resolve 标签与丢样统计，不另造同步每帧读回 |
| GPU 实例、LOD、通用读回与按需 buffer 已有实现 | [0.2.1 开发记录](../../../Engine/review/engine-0.2.1-gpu-instances.md) | 结构/像素验证不等于 GPU 时间收益或手机资格；G05 补正式性能与 Deferred 兼容证据 |
| 不带文本的动画消费端也承担字体解析器成本 | [0.2.0 包体评审](../../../Engine/review/release-0.2.0-capability-budgets.md)、[AnimationTextRasterizer](../../../Engine/extensions/src/animation/AnimationTextRasterizer.ts) | 可选文本适配器是有依据的后续包体优化；约 98 KB gzip 是历史配对诊断，当前需复测 |

0.2.0 的旧 AO、示例构建、Shader 预算和发布门禁问题已有后续处理，[冻结候选全局验收](../../../Engine/review/release-0.2.0-global-check.md) 记录通过。不得把早期失败继续当作当前未修复 bug，也不能把旧候选通过外推成新增 Deferred 已通过。

## 官方 WebGPU 示例的启发与边界

官方 [Deferred Rendering 示例](https://webgpu.github.io/webgpu-samples/?sample=deferredRendering) 的 [main.ts](https://github.com/webgpu/webgpu-samples/blob/main/sample/deferredRendering/main.ts) 使用默认 128、最多 1024 盏灯，灯光写入 storage buffer；G-buffer 包含法线、颜色和深度，compute pass 更新灯的位置。

[光照 shader](https://github.com/webgpu/webgpu-samples/blob/main/sample/deferredRendering/fragmentDeferredRendering.wgsl) 从深度重建世界坐标，每个有效像素遍历全部灯，并以半径排除无影响灯。它是延迟光照参考，不是已完成 tiled/clustered culling 的证明，也不是 Engine PBR、透明、阴影或多视图的性能保证。实现阶段须记录所参考的上游 commit；当前链接指向可变化的 main。

据此采用两步路线：先建立可验证的全灯 Deferred 参考，再增加 Tiled Deferred。G-buffer 把几何与光照分开，但其额外带宽可能使少灯或高分辨率场景变慢；分块减少局部灯稀疏场景的求值次数，高重叠场景则可能几乎不能剔除。

## 进一步迭代的排序

| 候选 | 建议 | 进入条件和验收方向 |
| --- | --- | --- |
| 帧资源复用、按需 shader/pipeline | 纳入 G02/G05 | 关闭 Deferred 时无 G-buffer 分配；兼容辅助输出避免重复几何 pass；记录峰值资源与冷启动时间 |
| 灯光源上传与 per-view 列表分离 | 纳入 G02/G05 | 同帧共享源记录；相机结果隔离；静态场景不反复传全量灯，改变相机不会重传未变源数据 |
| GPU 实例 CPU 提交/上传优化 | 纳入 G04/G05 | 使用既有 compute/LOD/visible ID ABI；测 1k/10k 实例及四视图，不以 draw call 数单独宣称加速 |
| 按需字体解析 | 候选 P1，单独立项 | 无文本入口移除解析器，无文本 gzip 相对当前配对样本目标减少至少 80 KB；真实字体轮廓、文本交互与旧同步入口行为不退化，不用 stub 作为产品实现 |
| SpotLight 与阴影 atlas | P2，拆成两项 | 先验证真实聚光需求及锥体剔除；阴影再单独评估投影灯数量、更新频率、可见性、纹理容量与质量；不承诺百灯百阴影 |
| 3D clustered / transparent Forward+ | 条件性后续 | 若 2D 分块因深度范围或透明灯光求值明显超预算，再比较 cluster 内存与构建成本；不得省略本版透明正确性回退 |
| Hi-Z 遮挡剔除 | P2 | 在已有视锥/LOD 基础上，先证明真实遮挡重的实例场景受益，并处理前帧相机突变和保守可见性 |
| 动态分辨率与动态画质 | P2 | 先获得可靠 GPU 时间与目标画质协议，再评估稳定控制、TAA 历史和 resize 成本 |
| CSM、WebGL2、Rust/Native 扩展 | 独立路线 | 以各自正式需求和设备证据准入；不作为 0.2.1 多灯功能前置 |

G01 可以调整候选排序，但不得据本表自行扩大本版必做范围。上述尚未测量的收益均为验证方向。

## 版本政策差异

协调仓 [repository-version-policy.json](../repository-version-policy.json) 当前仍登记 `>=0.1.0 <0.2.0`，而 Engine 源码已为 0.2.1。当前 `npm run check` 只验证原策略内部一致性。G01 需明确 Engine 独立候选线和消费方实际锁定版本的表达；不能全仓放宽 peer range，不能让 UI/Editor 同步发版成为 Engine 前置。本次只记录差异，不改历史兼容政策。
